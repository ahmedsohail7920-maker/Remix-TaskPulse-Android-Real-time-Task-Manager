/**
 * TaskPulse Type Definitions
 * Real-time Offline-First Android & Web Task Management
 */

export type Priority = 'low' | 'medium' | 'high' | 'urgent';
export type TaskStatus = 'todo' | 'in_progress' | 'completed' | 'archived';

export interface Subtask {
  id: string;
  title: string;
  completed: boolean;
}

export interface Task {
  id: string;
  userId: string;
  title: string;
  description?: string;
  priority: Priority;
  status: TaskStatus;
  category?: string;
  dueDate?: string; // ISO string or YYYY-MM-DDTHH:mm
  reminderTime?: string; // ISO string or YYYY-MM-DDTHH:mm
  isCompleted: boolean;
  completedAt?: string;
  tags?: string[];
  subtasks?: Subtask[];
  syncVersion: number;
  createdAt: string;
  updatedAt: string;
  // Local offline synchronization state
  _synced?: boolean;
  _pendingDelete?: boolean;
}

export interface Category {
  id: string;
  userId: string;
  name: string;
  color: string;
  icon: string;
}

export type SyncState = 'synced' | 'syncing' | 'offline' | 'error';

export interface SyncQueueItem {
  id: string;
  operation: 'create' | 'update' | 'delete';
  collection: 'tasks' | 'categories';
  data: Partial<Task | Category>;
  timestamp: number;
  retryCount: number;
}

export interface PushNotificationPayload {
  id: string;
  title: string;
  body: string;
  taskId: string;
  scheduledTime: string;
  sentAt?: string;
  read?: boolean;
}

export interface ApiEndpointDoc {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  path: string;
  summary: string;
  description: string;
  authRequired: boolean;
  requestBody?: Record<string, unknown>;
  responseExample: Record<string, unknown>;
  headers?: Record<string, string>;
}
