/**
 * Push Notification Manager & Reminder Scheduler
 * Handles native Web Push, in-app Android heads-up tray,
 * Web Audio chime alerts, and scheduled reminder execution.
 */
import { PushNotificationPayload, Task } from '../types';
import { offlineStore } from './offlineStore';

export interface ActiveHeadsUpAlert {
  id: string;
  taskId: string;
  title: string;
  body: string;
  time: string;
  priority: string;
}

class NotificationManager {
  private activeAlerts: ActiveHeadsUpAlert[] = [];
  private notificationHistory: PushNotificationPayload[] = [];
  private listeners: Set<() => void> = new Set();
  private checkInterval: number | null = null;
  private triggeredTaskIds: Set<string> = new Set();

  constructor() {
    this.initScheduler();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }

  public getActiveAlerts(): ActiveHeadsUpAlert[] {
    return [...this.activeAlerts];
  }

  public getHistory(): PushNotificationPayload[] {
    return [...this.notificationHistory];
  }

  public async requestPermission(): Promise<NotificationPermission> {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      try {
        const permission = await Notification.requestPermission();
        this.notify();
        return permission;
      } catch (e) {
        console.warn('Notification permission request error:', e);
      }
    }
    return 'default';
  }

  public getPermissionStatus(): NotificationPermission {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'denied';
  }

  /**
   * Synthesize high-definition Android notification chime via Web Audio API
   */
  public playNotificationSound() {
    if (typeof window === 'undefined') return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();

      // Note 1 (E5 - 659Hz)
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(659.25, ctx.currentTime);
      gain1.gain.setValueAtTime(0.2, ctx.currentTime);
      gain1.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(ctx.currentTime);
      osc1.stop(ctx.currentTime + 0.3);

      // Note 2 (A5 - 880Hz)
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(880, ctx.currentTime + 0.12);
      gain2.gain.setValueAtTime(0.25, ctx.currentTime + 0.12);
      gain2.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(ctx.currentTime + 0.12);
      osc2.stop(ctx.currentTime + 0.6);
    } catch (e) {
      // Audio autoplay policy might restrict if no prior user gesture
    }

    // Trigger haptic vibration if supported on Android device
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate([120, 80, 150]);
      } catch (e) {
        // ignore
      }
    }
  }

  /**
   * Dispatch a push notification alert for a task
   */
  public triggerNotification(task: Task, customMessage?: string) {
    const title = `Task Reminder: ${task.title}`;
    const body =
      customMessage ||
      (task.description
        ? task.description.substring(0, 100)
        : `Priority: ${task.priority.toUpperCase()} • Due: ${task.dueDate ? new Date(task.dueDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Soon'}`);

    // 1. Play sound
    this.playNotificationSound();

    // 2. In-App Heads-up notification item
    const alertId = 'alert-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
    const newAlert: ActiveHeadsUpAlert = {
      id: alertId,
      taskId: task.id,
      title,
      body,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      priority: task.priority,
    };
    this.activeAlerts.unshift(newAlert);

    // Save to history log
    this.notificationHistory.unshift({
      id: alertId,
      title,
      body,
      taskId: task.id,
      scheduledTime: task.reminderTime || new Date().toISOString(),
      sentAt: new Date().toISOString(),
      read: false,
    });

    // 3. Native Browser Notification (if granted)
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(title, {
          body,
          icon: '/favicon.ico',
          tag: task.id,
        });
      } catch (e) {
        console.warn('Native notification dispatch error:', e);
      }
    }

    this.notify();

    // Auto-dismiss heads-up after 12 seconds if not interacted
    setTimeout(() => {
      this.dismissAlert(alertId);
    }, 12000);
  }

  public dismissAlert(alertId: string) {
    this.activeAlerts = this.activeAlerts.filter((a) => a.id !== alertId);
    this.notify();
  }

  public completeTaskFromAlert(alertId: string, taskId: string) {
    offlineStore.toggleTaskCompletion(taskId);
    this.dismissAlert(alertId);
  }

  public snoozeTaskFromAlert(alertId: string, taskId: string, minutes: number = 10) {
    const nextReminder = new Date(Date.now() + minutes * 60 * 1000).toISOString();
    offlineStore.updateTask(taskId, { reminderTime: nextReminder });
    this.triggeredTaskIds.delete(taskId);
    this.dismissAlert(alertId);
  }

  /**
   * Periodic scheduler checking upcoming task reminder times
   */
  private initScheduler() {
    if (typeof window === 'undefined') return;

    this.checkInterval = window.setInterval(() => {
      const now = Date.now();
      const tasks = offlineStore.getTasks();

      tasks.forEach((task) => {
        if (task.isCompleted || !task.reminderTime) return;

        const reminderTimestamp = new Date(task.reminderTime).getTime();
        // If reminder time is within past 60 seconds and hasn't been triggered yet
        if (reminderTimestamp <= now && reminderTimestamp >= now - 120000 && !this.triggeredTaskIds.has(task.id)) {
          this.triggeredTaskIds.add(task.id);
          this.triggerNotification(task);
        }
      });
    }, 10000);
  }
}

export const notificationManager = new NotificationManager();
