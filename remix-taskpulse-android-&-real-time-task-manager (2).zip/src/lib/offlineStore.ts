/**
 * Offline-First Storage Engine & Sync Orchestrator
 * Provides instantaneous local reads/writes, conflict-free sync queue,
 * and seamless background synchronization with Firebase Firestore.
 */
import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  Unsubscribe,
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from './firebase';
import { Task, Category, SyncQueueItem, SyncState } from '../types';

const STORAGE_KEY_TASKS = 'taskpulse_local_tasks';
const STORAGE_KEY_CATEGORIES = 'taskpulse_local_categories';
const STORAGE_KEY_QUEUE = 'taskpulse_sync_queue';
const STORAGE_KEY_OFFLINE_SIM = 'taskpulse_sim_offline';

// Default starter tasks to demonstrate offline-first task management immediately
export const DEFAULT_CATEGORIES: Category[] = [
  { id: 'cat-android', userId: 'default', name: 'Android Dev', color: '#10b981', icon: 'smartphone' },
  { id: 'cat-backend', userId: 'default', name: 'Firebase & Cloud', color: '#06b6d4', icon: 'cloud' },
  { id: 'cat-security', userId: 'default', name: 'Security & Auth', color: '#8b5cf6', icon: 'shield' },
  { id: 'cat-general', userId: 'default', name: 'General', color: '#f59e0b', icon: 'check-circle' },
];

export const DEFAULT_TASKS: Task[] = [
  {
    id: 'task-1',
    userId: 'default',
    title: 'Generate production Android APK bundle',
    description: 'Compile signed release APK with ProGuard obfuscation, FCM push service, and Room SQLite database schema.',
    priority: 'urgent',
    status: 'in_progress',
    category: 'cat-android',
    dueDate: new Date(Date.now() + 3600 * 1000 * 4).toISOString(),
    reminderTime: new Date(Date.now() + 3600 * 1000 * 2).toISOString(),
    isCompleted: false,
    tags: ['android', 'apk', 'gradle'],
    subtasks: [
      { id: 'st-1', title: 'Verify AndroidManifest permissions', completed: true },
      { id: 'st-2', title: 'Inject google-services.json configuration', completed: true },
      { id: 'st-3', title: 'Run ./gradlew assembleDebug', completed: false },
    ],
    syncVersion: 1,
    createdAt: new Date(Date.now() - 3600 * 1000 * 12).toISOString(),
    updatedAt: new Date(Date.now() - 3600 * 1000 * 2).toISOString(),
    _synced: true,
  },
  {
    id: 'task-2',
    userId: 'default',
    title: 'Test offline sync with Airplane Mode simulator',
    description: 'Toggle simulated offline mode, add new tasks, edit priority, and verify that changes queue locally and auto-sync when online.',
    priority: 'high',
    status: 'todo',
    category: 'cat-backend',
    dueDate: new Date(Date.now() + 3600 * 1000 * 24).toISOString(),
    reminderTime: new Date(Date.now() + 3600 * 1000 * 5).toISOString(),
    isCompleted: false,
    tags: ['offline', 'firestore', 'cache'],
    subtasks: [
      { id: 'st-4', title: 'Enable offline mode toggle', completed: false },
      { id: 'st-5', title: 'Create pending task mutation', completed: false },
      { id: 'st-6', title: 'Re-enable online mode and inspect queue flush', completed: false },
    ],
    syncVersion: 1,
    createdAt: new Date(Date.now() - 3600 * 1000 * 8).toISOString(),
    updatedAt: new Date(Date.now() - 3600 * 1000 * 4).toISOString(),
    _synced: true,
  },
  {
    id: 'task-3',
    userId: 'default',
    title: 'Verify FCM push notification reminder alerts',
    description: 'Schedule a task reminder for 1 minute from now to test the heads-up notification chime and action buttons.',
    priority: 'medium',
    status: 'todo',
    category: 'cat-android',
    dueDate: new Date(Date.now() + 3600 * 1000 * 48).toISOString(),
    reminderTime: new Date(Date.now() + 60 * 1000 * 5).toISOString(),
    isCompleted: false,
    tags: ['push', 'fcm', 'reminders'],
    subtasks: [],
    syncVersion: 1,
    createdAt: new Date(Date.now() - 3600 * 1000 * 6).toISOString(),
    updatedAt: new Date(Date.now() - 3600 * 1000 * 3).toISOString(),
    _synced: true,
  },
  {
    id: 'task-4',
    userId: 'default',
    title: 'Audit Zero-Trust Firestore ABAC Security Rules',
    description: 'Confirm that all read/write paths enforce request.auth.uid invariants, size limitations, and schema constraints.',
    priority: 'high',
    status: 'completed',
    category: 'cat-security',
    dueDate: new Date(Date.now() - 3600 * 1000 * 1).toISOString(),
    isCompleted: true,
    completedAt: new Date(Date.now() - 3600 * 1000 * 1).toISOString(),
    tags: ['security', 'rules', 'audit'],
    subtasks: [
      { id: 'st-7', title: 'Deploy rules with fax.DeployRules', completed: true },
      { id: 'st-8', title: 'Check Dirty Dozen adversarial tests', completed: true },
    ],
    syncVersion: 2,
    createdAt: new Date(Date.now() - 3600 * 1000 * 20).toISOString(),
    updatedAt: new Date(Date.now() - 3600 * 1000 * 1).toISOString(),
    _synced: true,
  },
];

class OfflineStore {
  private tasks: Task[] = [];
  private categories: Category[] = [];
  private syncQueue: SyncQueueItem[] = [];
  private syncState: SyncState = 'synced';
  private simulatedOffline: boolean = false;
  private listeners: Set<() => void> = new Set();
  private firestoreUnsubscribe: Unsubscribe | null = null;
  private isDrainingQueue: boolean = false;

  constructor() {
    this.loadFromStorage();
    // Watch online/offline browser network status
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => this.handleNetworkChange());
      window.addEventListener('offline', () => this.handleNetworkChange());
    }
  }

  private loadFromStorage() {
    try {
      const storedTasks = localStorage.getItem(STORAGE_KEY_TASKS);
      const storedCategories = localStorage.getItem(STORAGE_KEY_CATEGORIES);
      const storedQueue = localStorage.getItem(STORAGE_KEY_QUEUE);
      const storedOfflineSim = localStorage.getItem(STORAGE_KEY_OFFLINE_SIM);

      this.tasks = storedTasks ? JSON.parse(storedTasks) : DEFAULT_TASKS;
      this.categories = storedCategories ? JSON.parse(storedCategories) : DEFAULT_CATEGORIES;
      this.syncQueue = storedQueue ? JSON.parse(storedQueue) : [];
      this.simulatedOffline = storedOfflineSim === 'true';

      this.updateSyncState();
    } catch (e) {
      console.warn('Error reading offline storage, using defaults:', e);
      this.tasks = DEFAULT_TASKS;
      this.categories = DEFAULT_CATEGORIES;
    }
  }

  private saveToStorage() {
    try {
      localStorage.setItem(STORAGE_KEY_TASKS, JSON.stringify(this.tasks));
      localStorage.setItem(STORAGE_KEY_CATEGORIES, JSON.stringify(this.categories));
      localStorage.setItem(STORAGE_KEY_QUEUE, JSON.stringify(this.syncQueue));
      localStorage.setItem(STORAGE_KEY_OFFLINE_SIM, String(this.simulatedOffline));
    } catch (e) {
      console.error('Failed to save to localStorage:', e);
    }
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.saveToStorage();
    this.listeners.forEach((listener) => listener());
  }

  public getTasks(): Task[] {
    return [...this.tasks].filter((t) => !t._pendingDelete);
  }

  public getCategories(): Category[] {
    return [...this.categories];
  }

  public getSyncQueue(): SyncQueueItem[] {
    return [...this.syncQueue];
  }

  public getSyncState(): SyncState {
    return this.syncState;
  }

  public isOfflineMode(): boolean {
    return this.simulatedOffline || (typeof navigator !== 'undefined' && !navigator.onLine);
  }

  public setSimulatedOffline(val: boolean) {
    this.simulatedOffline = val;
    this.updateSyncState();
    this.notify();
    if (!val) {
      this.drainQueue();
    }
  }

  private updateSyncState() {
    if (this.isOfflineMode()) {
      this.syncState = 'offline';
    } else if (this.isDrainingQueue) {
      this.syncState = 'syncing';
    } else if (this.syncQueue.length > 0) {
      this.syncState = 'syncing';
    } else {
      this.syncState = 'synced';
    }
  }

  private handleNetworkChange() {
    this.updateSyncState();
    this.notify();
    if (!this.isOfflineMode()) {
      this.drainQueue();
    }
  }

  /**
   * Optimistic Local CRUD Operations
   */
  public addTask(taskData: Omit<Task, 'id' | 'userId' | 'syncVersion' | 'createdAt' | 'updatedAt'>): Task {
    const currentUserId = auth.currentUser?.uid || 'local-user';
    const now = new Date().toISOString();
    const newTask: Task = {
      ...taskData,
      id: 'task-' + Math.random().toString(36).substring(2, 11),
      userId: currentUserId,
      syncVersion: 1,
      createdAt: now,
      updatedAt: now,
      _synced: false,
    };

    this.tasks = [newTask, ...this.tasks];
    this.enqueueMutation('create', 'tasks', newTask.id, newTask);
    this.notify();
    this.triggerSync();
    return newTask;
  }

  public updateTask(id: string, updates: Partial<Task>): Task | null {
    const index = this.tasks.findIndex((t) => t.id === id);
    if (index === -1) return null;

    const existing = this.tasks[index];
    const updated: Task = {
      ...existing,
      ...updates,
      syncVersion: (existing.syncVersion || 0) + 1,
      updatedAt: new Date().toISOString(),
      _synced: false,
    };

    this.tasks[index] = updated;
    this.enqueueMutation('update', 'tasks', id, updated);
    this.notify();
    this.triggerSync();
    return updated;
  }

  public toggleTaskCompletion(id: string): Task | null {
    const task = this.tasks.find((t) => t.id === id);
    if (!task) return null;

    const nextCompleted = !task.isCompleted;
    return this.updateTask(id, {
      isCompleted: nextCompleted,
      status: nextCompleted ? 'completed' : 'todo',
      completedAt: nextCompleted ? new Date().toISOString() : undefined,
    });
  }

  public deleteTask(id: string) {
    const index = this.tasks.findIndex((t) => t.id === id);
    if (index === -1) return;

    this.tasks[index]._pendingDelete = true;
    this.enqueueMutation('delete', 'tasks', id, { id });
    // Remove from local list after enqueue
    this.tasks = this.tasks.filter((t) => t.id !== id);
    this.notify();
    this.triggerSync();
  }

  public addCategory(name: string, color: string, icon: string = 'folder'): Category {
    const currentUserId = auth.currentUser?.uid || 'local-user';
    const newCat: Category = {
      id: 'cat-' + Math.random().toString(36).substring(2, 9),
      userId: currentUserId,
      name,
      color,
      icon,
    };
    this.categories.push(newCat);
    this.enqueueMutation('create', 'categories', newCat.id, newCat);
    this.notify();
    this.triggerSync();
    return newCat;
  }

  private enqueueMutation(
    operation: 'create' | 'update' | 'delete',
    collection: 'tasks' | 'categories',
    id: string,
    data: Partial<Task | Category>
  ) {
    // If a previous un-synced mutation exists for the same item, coalesce
    const existingIndex = this.syncQueue.findIndex((item) => item.id === id && item.collection === collection);
    if (existingIndex >= 0) {
      if (operation === 'delete') {
        this.syncQueue[existingIndex] = {
          id,
          operation: 'delete',
          collection,
          data,
          timestamp: Date.now(),
          retryCount: 0,
        };
      } else {
        this.syncQueue[existingIndex] = {
          ...this.syncQueue[existingIndex],
          data: { ...this.syncQueue[existingIndex].data, ...data },
          timestamp: Date.now(),
        };
      }
    } else {
      this.syncQueue.push({
        id,
        operation,
        collection,
        data,
        timestamp: Date.now(),
        retryCount: 0,
      });
    }
  }

  /**
   * Queue Draining & Synchronization with Firestore
   */
  private async triggerSync() {
    if (this.isOfflineMode()) {
      this.updateSyncState();
      return;
    }
    await this.drainQueue();
  }

  public async drainQueue(): Promise<void> {
    if (this.isDrainingQueue || this.isOfflineMode() || this.syncQueue.length === 0) {
      this.updateSyncState();
      return;
    }

    const currentUser = auth.currentUser;
    if (!currentUser) {
      // If user is not logged in to Firebase, queue stays safe in local storage
      this.updateSyncState();
      return;
    }

    this.isDrainingQueue = true;
    this.syncState = 'syncing';
    this.notify();

    const itemsToProcess = [...this.syncQueue];

    for (const item of itemsToProcess) {
      try {
        if (item.collection === 'tasks') {
          const taskDocRef = doc(db, 'tasks', item.id);
          if (item.operation === 'delete') {
            await deleteDoc(taskDocRef);
          } else {
            // Ensure userId matches current authenticated user for Firestore ABAC rules
            const payload = {
              ...(item.data as Task),
              userId: currentUser.uid,
            };
            // Clean local metadata before sending to Firestore
            delete (payload as any)._synced;
            delete (payload as any)._pendingDelete;

            await setDoc(taskDocRef, payload, { merge: true });

            // Mark local task as synced
            const localTask = this.tasks.find((t) => t.id === item.id);
            if (localTask) {
              localTask._synced = true;
            }
          }
        } else if (item.collection === 'categories') {
          const catDocRef = doc(db, 'categories', item.id);
          if (item.operation === 'delete') {
            await deleteDoc(catDocRef);
          } else {
            const payload = {
              ...(item.data as Category),
              userId: currentUser.uid,
            };
            await setDoc(catDocRef, payload, { merge: true });
          }
        }

        // Remove from queue on success
        this.syncQueue = this.syncQueue.filter((q) => q.id !== item.id);
      } catch (err) {
        console.warn(`Sync failed for item ${item.id}:`, err);
        item.retryCount = (item.retryCount || 0) + 1;
        // If max retries reached or security error, keep for later resolution
        if (item.retryCount > 5) {
          this.syncState = 'error';
        }
      }
    }

    this.isDrainingQueue = false;
    this.updateSyncState();
    this.notify();
  }

  /**
   * Set up Real-Time Firestore Listener for logged-in user
   */
  public attachFirestoreListener() {
    if (this.firestoreUnsubscribe) {
      this.firestoreUnsubscribe();
      this.firestoreUnsubscribe = null;
    }

    const user = auth.currentUser;
    if (!user) return;

    try {
      const q = query(collection(db, 'tasks'), where('userId', '==', user.uid));
      this.firestoreUnsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const remoteTasks: Task[] = [];
          snapshot.forEach((docSnap) => {
            remoteTasks.push({ ...(docSnap.data() as Task), id: docSnap.id, _synced: true });
          });

          // Merge remote with local un-synced items (LWW resolution)
          this.mergeRemoteTasks(remoteTasks);
        },
        (error) => {
          handleFirestoreError(error, OperationType.LIST, 'tasks');
        }
      );
    } catch (e) {
      console.error('Error attaching Firestore listener:', e);
    }
  }

  public detachFirestoreListener() {
    if (this.firestoreUnsubscribe) {
      this.firestoreUnsubscribe();
      this.firestoreUnsubscribe = null;
    }
  }

  private mergeRemoteTasks(remoteTasks: Task[]) {
    const queueIds = new Set(this.syncQueue.map((q) => q.id));

    // For any task not currently pending local mutations, update with remote
    const mergedMap = new Map<string, Task>();

    // First put local tasks
    for (const t of this.tasks) {
      mergedMap.set(t.id, t);
    }

    // Now reconcile remote tasks
    for (const remote of remoteTasks) {
      if (queueIds.has(remote.id)) {
        // Local has pending changes, keep local until queue drain
        continue;
      }
      const local = mergedMap.get(remote.id);
      if (!local || (remote.syncVersion || 0) >= (local.syncVersion || 0)) {
        mergedMap.set(remote.id, remote);
      }
    }

    this.tasks = Array.from(mergedMap.values());
    this.notify();
  }
}

export const offlineStore = new OfflineStore();
