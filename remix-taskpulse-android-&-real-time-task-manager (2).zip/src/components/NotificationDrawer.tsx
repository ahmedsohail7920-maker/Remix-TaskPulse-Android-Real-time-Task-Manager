import React, { useState } from 'react';
import {
  Bell,
  Volume2,
  CheckCircle,
  Clock,
  Sparkles,
  Shield,
  Smartphone,
  Trash2,
  Radio,
} from 'lucide-react';
import { notificationManager } from '../lib/notificationManager';
import { Task } from '../types';

interface NotificationDrawerProps {
  tasks: Task[];
  onTriggerTestNotification: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  tasks,
  onTriggerTestNotification,
}) => {
  const [permission, setPermission] = useState<NotificationPermission>(
    notificationManager.getPermissionStatus()
  );
  const history = notificationManager.getHistory();

  const handleRequestPermission = async () => {
    const res = await notificationManager.requestPermission();
    setPermission(res);
  };

  const tasksWithReminders = tasks.filter((t) => t.reminderTime && !t.isCompleted);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 text-slate-100">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <div>
          <h1 className="text-2xl font-extrabold text-white flex items-center space-x-2">
            <Bell className="w-6 h-6 text-cyan-400" />
            <span>Push Notifications & Task Reminders</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Android Exact AlarmManager, Web Notifications API, and synthesized heads-up audio chimes
          </p>
        </div>

        {/* Test Notification Trigger */}
        <button
          onClick={onTriggerTestNotification}
          className="px-4 py-2 rounded-xl text-xs font-semibold bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 hover:from-cyan-400 hover:to-blue-500 shadow-lg shadow-cyan-500/20 active:scale-95 transition-all flex items-center space-x-1.5"
        >
          <Volume2 className="w-4 h-4" />
          <span>Test Push Reminder</span>
        </button>
      </div>

      {/* Permission Card */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 mb-6 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                permission === 'granted'
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                  : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
              }`}
            >
              <Radio className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-white">System Push Notification Status</h3>
                <span
                  className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                    permission === 'granted'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : 'bg-amber-950 text-amber-400 border border-amber-800'
                  }`}
                >
                  {permission}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {permission === 'granted'
                  ? 'System and browser push alerts are active with high-priority chime alerts.'
                  : 'Grant notification permission to receive native device popups when deadlines approach.'}
              </p>
            </div>
          </div>

          {permission !== 'granted' && (
            <button
              onClick={handleRequestPermission}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-cyan-500 text-slate-950 hover:bg-cyan-400 transition-colors"
            >
              Enable Push
            </button>
          )}
        </div>
      </div>

      {/* Two Column Grid: Scheduled Reminders & FCM Architecture */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Scheduled Reminders */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-xl">
          <h3 className="text-sm font-bold text-white mb-3 flex items-center space-x-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            <span>Active Scheduled Reminders ({tasksWithReminders.length})</span>
          </h3>

          {tasksWithReminders.length === 0 ? (
            <div className="p-6 rounded-xl bg-slate-950/60 border border-slate-800/80 text-center text-xs text-slate-500">
              No tasks currently have pending reminder alarms. Edit or create a task with a reminder time to see it queued here!
            </div>
          ) : (
            <div className="space-y-2">
              {tasksWithReminders.map((task) => (
                <div
                  key={task.id}
                  className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between"
                >
                  <div>
                    <h4 className="text-xs font-semibold text-slate-200">{task.title}</h4>
                    <span className="text-[11px] text-amber-400 flex items-center space-x-1 mt-0.5 font-mono">
                      <Clock className="w-3 h-3" />
                      <span>{new Date(task.reminderTime!).toLocaleString()}</span>
                    </span>
                  </div>
                  <span className="text-[9px] uppercase font-bold px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                    {task.priority}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Android Push Notification Protocol Spec */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-xl">
          <h3 className="text-sm font-bold text-white mb-3 flex items-center space-x-2">
            <Smartphone className="w-4 h-4 text-cyan-400" />
            <span>Android Notification Architecture</span>
          </h3>

          <div className="space-y-2.5 text-xs text-slate-300">
            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[11px] font-bold text-cyan-300 block mb-0.5">Channel ID:</span>
              <code className="text-[11px] font-mono text-slate-400">channel_taskpulse_reminders</code>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[11px] font-bold text-cyan-300 block mb-0.5">Importance:</span>
              <span className="text-slate-400">IMPORTANCE_HIGH (Triggers full heads-up banner & screen wake)</span>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[11px] font-bold text-cyan-300 block mb-0.5">Haptic Vibration Pattern:</span>
              <code className="text-[11px] font-mono text-slate-400">longArrayOf(0, 250, 150, 250)</code>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[11px] font-bold text-cyan-300 block mb-0.5">Doze Mode Bypassing:</span>
              <span className="text-slate-400">AlarmManager.setExactAndAllowWhileIdle() ensures trigger on time.</span>
            </div>
          </div>
        </div>
      </div>

      {/* Dispatched Notification History */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-xl">
        <h3 className="text-sm font-bold text-white mb-3 flex items-center space-x-2">
          <Bell className="w-4 h-4 text-cyan-400" />
          <span>Recent Dispatched Push Alerts ({history.length})</span>
        </h3>

        {history.length === 0 ? (
          <div className="p-6 rounded-xl bg-slate-950/60 border border-slate-800/80 text-center text-xs text-slate-500">
            No notification alerts dispatched yet. Click "Test Push Reminder" above to fire a live alert.
          </div>
        ) : (
          <div className="space-y-2">
            {history.slice(0, 5).map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-start justify-between"
              >
                <div>
                  <h4 className="text-xs font-semibold text-cyan-200">{item.title}</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">{item.body}</p>
                </div>
                <span className="text-[10px] text-slate-500 font-mono shrink-0 ml-4">
                  {item.sentAt ? new Date(item.sentAt).toLocaleTimeString() : 'Just now'}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
