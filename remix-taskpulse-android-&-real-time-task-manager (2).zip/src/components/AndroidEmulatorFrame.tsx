import React, { useState, useEffect } from 'react';
import {
  Wifi,
  WifiOff,
  BatteryCharging,
  Maximize2,
  Minimize2,
  Smartphone,
  CheckCircle2,
  Clock,
  X,
  Volume2,
} from 'lucide-react';
import { ActiveHeadsUpAlert } from '../lib/notificationManager';

interface AndroidEmulatorFrameProps {
  children: React.ReactNode;
  isOffline: boolean;
  activeAlerts: ActiveHeadsUpAlert[];
  onDismissAlert: (id: string) => void;
  onCompleteAlert: (alertId: string, taskId: string) => void;
  onSnoozeAlert: (alertId: string, taskId: string) => void;
  onOpenCreateModal: () => void;
}

export const AndroidEmulatorFrame: React.FC<AndroidEmulatorFrameProps> = ({
  children,
  isOffline,
  activeAlerts,
  onDismissAlert,
  onCompleteAlert,
  onSnoozeAlert,
  onOpenCreateModal,
}) => {
  const [currentTime, setCurrentTime] = useState<string>('09:41');
  const [isExpanded, setIsExpanded] = useState<boolean>(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center p-2 sm:p-6 w-full min-h-[calc(100vh-5rem)]">
      {/* Top Controller Bar */}
      <div className="w-full max-w-5xl mb-4 flex items-center justify-between px-2">
        <div className="flex items-center space-x-2">
          <span className="flex items-center space-x-1.5 text-xs text-slate-400">
            <Smartphone className="w-4 h-4 text-cyan-400" />
            <span className="font-semibold text-slate-200">
              {isExpanded ? 'Android Tablet Experience (16:10)' : 'Android Phone (Pixel 8 / Material Dark 3)'}
            </span>
          </span>
          <span className="text-slate-600">•</span>
          <span className="text-[11px] font-mono text-slate-400">Android SDK 35 (Vanilla Dark)</span>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition-colors"
          >
            {isExpanded ? (
              <>
                <Minimize2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Phone View</span>
              </>
            ) : (
              <>
                <Maximize2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Expanded Canvas</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Android Device Body */}
      <div
        className={`transition-all duration-300 relative flex flex-col rounded-[2.5rem] p-3 shadow-2xl ${
          isExpanded
            ? 'w-full max-w-5xl h-[860px] bg-slate-900/90 border-2 border-slate-800'
            : 'w-full max-w-[420px] h-[850px] bg-slate-950 border-[6px] border-slate-800 shadow-[0_0_50px_rgba(6,182,212,0.12)]'
        }`}
      >
        {/* Device Outer Glow & Speaker Grille */}
        {!isExpanded && (
          <div className="absolute top-2 left-1/2 -translate-x-1/2 w-20 h-1 rounded-full bg-slate-700/60 z-30" />
        )}

        {/* Screen Bezel & Container */}
        <div className="relative w-full h-full rounded-[2rem] bg-slate-950 flex flex-col overflow-hidden border border-slate-800/80">
          {/* Android Status Bar */}
          <div className="h-10 px-5 flex items-center justify-between bg-slate-950/90 backdrop-blur-sm z-30 select-none border-b border-slate-900">
            {/* Clock */}
            <div className="text-xs font-semibold text-slate-200 tracking-tight pl-1 font-mono">
              {currentTime}
            </div>

            {/* Android Punch-hole Camera Notch */}
            <div className="w-4 h-4 rounded-full bg-black border border-slate-800 flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-slate-900" />
            </div>

            {/* Status Icons */}
            <div className="flex items-center space-x-2 text-slate-300 pr-1">
              <span className="text-[10px] font-bold font-mono text-cyan-400 tracking-wider">5G</span>
              {isOffline ? (
                <WifiOff className="w-3.5 h-3.5 text-amber-400" />
              ) : (
                <Wifi className="w-3.5 h-3.5 text-slate-300" />
              )}
              <div className="flex items-center space-x-0.5">
                <span className="text-[10px] font-mono text-slate-300">98%</span>
                <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
              </div>
            </div>
          </div>

          {/* Android Heads-Up Push Notification Drawer Alerts */}
          {activeAlerts.length > 0 && (
            <div className="absolute top-11 inset-x-2 z-40 space-y-2 pointer-events-auto animate-in slide-in-from-top-4 duration-200">
              {activeAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className="rounded-2xl bg-slate-900/95 border border-cyan-500/40 p-3.5 shadow-2xl backdrop-blur-xl text-slate-100"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-6 h-6 rounded-lg bg-cyan-500 flex items-center justify-center text-slate-950 font-bold text-xs">
                        <Volume2 className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-1.5">
                          <span className="text-xs font-bold text-white">Zoya AI</span>
                          <span className="text-[10px] text-slate-400">• {alert.time}</span>
                          <span className="text-[9px] uppercase font-bold px-1 rounded bg-rose-950 text-rose-400 border border-rose-800">
                            {alert.priority}
                          </span>
                        </div>
                        <h4 className="text-xs font-semibold text-cyan-200 mt-0.5">{alert.title}</h4>
                      </div>
                    </div>
                    <button
                      onClick={() => onDismissAlert(alert.id)}
                      className="text-slate-400 hover:text-slate-200 p-0.5"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-1 pl-8 line-clamp-2">{alert.body}</p>

                  {/* Android Quick Action Buttons */}
                  <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-end space-x-2 pl-8">
                    <button
                      onClick={() => onSnoozeAlert(alert.id, alert.taskId)}
                      className="px-2.5 py-1 rounded-lg text-[10px] font-medium bg-slate-800 text-slate-300 hover:bg-slate-700 flex items-center space-x-1"
                    >
                      <Clock className="w-3 h-3 text-amber-400" />
                      <span>Snooze 10m</span>
                    </button>
                    <button
                      onClick={() => onCompleteAlert(alert.id, alert.taskId)}
                      className="px-2.5 py-1 rounded-lg text-[10px] font-semibold bg-cyan-500 text-slate-950 hover:bg-cyan-400 flex items-center space-x-1 shadow-sm"
                    >
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Done</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Main App Screen Scrollable Content */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden flex flex-col relative custom-scrollbar">
            {children}
          </div>

          {/* Android Bottom Navigation Gesture Bar */}
          <div className="h-6 bg-slate-950 flex items-center justify-center select-none border-t border-slate-900/60 z-30">
            <div className="w-32 h-1 rounded-full bg-slate-600 hover:bg-slate-400 transition-colors cursor-pointer" />
          </div>
        </div>
      </div>
    </div>
  );
};
