import React, { useState } from 'react';
import {
  Download,
  Package,
  FileCode,
  CheckCircle,
  Copy,
  Terminal,
  FolderArchive,
  Layers,
  Sparkles,
  Shield,
  Smartphone,
  ExternalLink,
} from 'lucide-react';
import {
  getAndroidProjectFiles,
  downloadAndroidProjectZip,
  downloadDebugApkPackage,
  AndroidFileDefinition,
} from '../lib/androidProjectGenerator';

export const ApkBuildSuite: React.FC = () => {
  const [isExportingZip, setIsExportingZip] = useState(false);
  const [isDownloadingApk, setIsDownloadingApk] = useState(false);
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [copied, setCopied] = useState(false);

  const projectFiles = getAndroidProjectFiles();
  const currentFile = projectFiles[selectedFileIndex] || projectFiles[0];

  const handleDownloadZip = async () => {
    setIsExportingZip(true);
    try {
      await downloadAndroidProjectZip();
    } finally {
      setIsExportingZip(false);
    }
  };

  const handleDownloadApk = async () => {
    setIsDownloadingApk(true);
    try {
      await downloadDebugApkPackage();
    } finally {
      setIsDownloadingApk(false);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 text-slate-100">
      {/* Hero Header */}
      <div className="rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900/90 to-cyan-950/40 border border-slate-800 p-6 sm:p-8 relative overflow-hidden shadow-2xl mb-8">
        <div className="absolute right-0 top-0 -mt-10 -mr-10 w-80 h-80 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div className="max-w-xl">
            <div className="flex items-center space-x-2 mb-3">
              <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 flex items-center space-x-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Native Android Build Engine</span>
              </span>
              <span className="text-xs text-slate-400">Target SDK 35 (Android 15)</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Zoya AI APK Build & Source Export Suite
            </h1>
            <p className="text-sm text-slate-300 mt-2 leading-relaxed">
              Complete production Android application built with Jetpack Compose Material 3 dark theme,
              offline-first Room SQLite storage, WorkManager background synchronization, and exact push notification alarms.
            </p>

            <div className="mt-4 flex flex-wrap gap-2 text-xs font-mono text-slate-400">
              <span className="px-2 py-1 rounded-md bg-slate-950 border border-slate-800">com.zoya.ai.app</span>
              <span className="px-2 py-1 rounded-md bg-slate-950 border border-slate-800">Version 1.0.0 (Code 1)</span>
              <span className="px-2 py-1 rounded-md bg-slate-950 border border-slate-800">MinSDK 26 (Android 8+)</span>
            </div>
          </div>

          {/* Quick Action Download Cards */}
          <div className="flex flex-col sm:flex-row md:flex-col gap-3 shrink-0">
            {/* Download APK Button */}
            <button
              onClick={handleDownloadApk}
              disabled={isDownloadingApk}
              className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-sm shadow-xl shadow-cyan-500/20 active:scale-95 transition-all flex items-center justify-center space-x-2"
            >
              <Package className="w-5 h-5" />
              <span>{isDownloadingApk ? 'Generating Package...' : 'Download Android APK (.apk)'}</span>
            </button>

            {/* Download Android Studio Zip */}
            <button
              onClick={handleDownloadZip}
              disabled={isExportingZip}
              className="px-6 py-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-semibold text-sm active:scale-95 transition-all flex items-center justify-center space-x-2"
            >
              <FolderArchive className="w-5 h-5 text-cyan-400" />
              <span>{isExportingZip ? 'Packaging Source...' : 'Download Android Studio (.zip)'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Architecture Highlights Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-3">
            <Layers className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-white">Offline Room SQLite Engine</h3>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Local SQLite database with reactive Kotlin Flow observations. Every task is cached instantly for zero-latency offline operation.
          </p>
        </div>

        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 mb-3">
            <Smartphone className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-white">FCM & Exact Push Alarms</h3>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Uses Android <code className="text-purple-300 font-mono">SCHEDULE_EXACT_ALARM</code> and high-priority Notification Channels to guarantee reminders ring on time even in Doze mode.
          </p>
        </div>

        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-3">
            <Shield className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-white">WorkManager Firestore Sync</h3>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Exponential backoff retry policy syncing offline mutations with Firebase Firestore when network connectivity is established.
          </p>
        </div>
      </div>

      {/* Source Code Inspector */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl mb-8">
        {/* File Tabs Header */}
        <div className="border-b border-slate-800 bg-slate-950 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <FileCode className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-bold text-white">Android Project Codebase</span>
          </div>

          <button
            onClick={handleCopyCode}
            className="flex items-center space-x-1 px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            {copied ? <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy File'}</span>
          </button>
        </div>

        {/* Tab File Selector Strip */}
        <div className="flex items-center space-x-1 px-4 py-2 bg-slate-950/70 border-b border-slate-800/80 overflow-x-auto custom-scrollbar">
          {projectFiles.map((f, idx) => (
            <button
              key={f.path}
              onClick={() => setSelectedFileIndex(idx)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono whitespace-nowrap transition-colors ${
                selectedFileIndex === idx
                  ? 'bg-slate-800 text-cyan-400 font-semibold border border-cyan-800/50'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              {f.filename}
            </button>
          ))}
        </div>

        {/* Code Content & Description */}
        <div className="p-4 bg-slate-950">
          <div className="mb-2 text-xs text-slate-400 flex items-center justify-between">
            <span>{currentFile.description}</span>
            <span className="font-mono text-[11px] text-slate-500">{currentFile.path}</span>
          </div>

          <pre className="p-4 rounded-xl bg-slate-900 border border-slate-800 font-mono text-xs text-slate-200 overflow-x-auto max-h-[460px] custom-scrollbar leading-relaxed">
            <code>{currentFile.content}</code>
          </pre>
        </div>
      </div>

      {/* CLI Compilation Guide */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-6">
        <h3 className="text-base font-bold text-white mb-2 flex items-center space-x-2">
          <Terminal className="w-4 h-4 text-cyan-400" />
          <span>How to Compile & Install on Real Devices</span>
        </h3>

        <div className="space-y-4 text-xs text-slate-300">
          <div>
            <h4 className="font-semibold text-cyan-300 mb-1">Option 1: Compile from Terminal</h4>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-slate-300 space-y-1">
              <p className="text-slate-500"># 1. Extract the downloaded project</p>
              <p>unzip Zoya-AI-Android-Project.zip -d zoya-ai/</p>
              <p>cd zoya-ai</p>
              <p className="text-slate-500 mt-2"># 2. Build debug APK using Gradle wrapper</p>
              <p>chmod +x gradlew</p>
              <p>./gradlew assembleDebug</p>
              <p className="text-slate-500 mt-2"># 3. Output APK:</p>
              <p className="text-emerald-400">app/build/outputs/apk/debug/app-debug.apk</p>
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-cyan-300 mb-1">Option 2: Install via Android ADB</h4>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-slate-300 space-y-1">
              <p>adb devices</p>
              <p>adb install -r Zoya-AI-v1.0.0-debug.apk</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
