import React from 'react';
import {
  Sparkles,
  Smartphone,
  Terminal,
  ShieldCheck,
  Bell,
  Wifi,
  WifiOff,
  RefreshCw,
  Download,
  Flame,
  Clock,
  ListTodo,
  Zap,
} from 'lucide-react';
import { SyncState } from '../types';

export type ActiveTab = 'zoya' | 'tasks' | 'workflows' | 'emulator' | 'apk' | 'api' | 'notifications';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  syncState: SyncState;
  pendingCount: number;
  isSimulatedOffline: boolean;
  onToggleOffline: () => void;
  onManualSync: () => void;
  unreadNotifications: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  syncState,
  pendingCount,
  isSimulatedOffline,
  onToggleOffline,
  onManualSync,
  unreadNotifications,
}) => {
  return (
    <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand: Zoya AI */}
        <div
          onClick={() => setActiveTab('zoya')}
          className="flex items-center space-x-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-purple-600 to-pink-500 flex items-center justify-center shadow-lg shadow-cyan-500/25 group-hover:scale-105 transition-transform">
            <Sparkles className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-white via-cyan-200 to-pink-300 bg-clip-text text-transparent">
                Zoya AI
              </span>
              <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-gradient-to-r from-cyan-950 to-pink-950 text-cyan-300 border border-cyan-800/60">
                Voice & Tasks Agent
              </span>
            </div>
            <div className="flex items-center space-x-2 text-xs text-slate-400">
              <span className="flex items-center space-x-1">
                <Flame className="w-3 h-3 text-amber-500" />
                <span className="font-mono text-[11px] text-slate-300">Firebase Realtime Sync</span>
              </span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="hidden lg:flex items-center space-x-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('zoya')}
            className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'zoya'
                ? 'bg-gradient-to-r from-cyan-500 via-purple-600 to-pink-500 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-amber-300" />
            <span>Zoya Cockpit</span>
          </button>

          <button
            onClick={() => setActiveTab('tasks')}
            className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'tasks'
                ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <ListTodo className="w-3.5 h-3.5" />
            <span>Tasks</span>
          </button>

          <button
            onClick={() => setActiveTab('workflows')}
            className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'workflows'
                ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Workflows</span>
          </button>

          <button
            onClick={() => setActiveTab('emulator')}
            className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'emulator'
                ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Mobile App</span>
          </button>

          <button
            onClick={() => setActiveTab('apk')}
            className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'apk'
                ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>APK Suite</span>
          </button>

          <button
            onClick={() => setActiveTab('api')}
            className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'api'
                ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>APIs & Security</span>
          </button>

          <button
            onClick={() => setActiveTab('notifications')}
            className={`relative flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'notifications'
                ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Reminders</span>
            {unreadNotifications > 0 && (
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
            )}
          </button>
        </nav>

        {/* Right Controls: Offline Sim & Sync State */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Airplane Mode Toggle */}
          <button
            onClick={onToggleOffline}
            title={isSimulatedOffline ? 'Disable Airplane Mode (Go Online)' : 'Simulate Offline Mode (Airplane Mode)'}
            className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
              isSimulatedOffline
                ? 'bg-amber-950/60 border-amber-600/70 text-amber-300 hover:bg-amber-900/60'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            {isSimulatedOffline ? (
              <>
                <WifiOff className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Offline Mode</span>
              </>
            ) : (
              <>
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Online</span>
              </>
            )}
          </button>

          {/* Firestore Sync Badge */}
          <div
            onClick={onManualSync}
            title="Click to manually drain offline sync queue"
            className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg text-xs font-mono bg-slate-900 border border-slate-800 text-slate-300 cursor-pointer hover:border-slate-700 transition-colors"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${
                syncState === 'syncing'
                  ? 'text-cyan-400 animate-spin'
                  : syncState === 'offline'
                  ? 'text-amber-400'
                  : 'text-emerald-400'
              }`}
            />
            <span className="hidden md:inline">
              {syncState === 'syncing'
                ? 'Syncing...'
                : syncState === 'offline'
                ? `Queued (${pendingCount})`
                : 'Cloud Synced'}
            </span>
            {pendingCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-cyan-900/80 text-cyan-300 border border-cyan-700">
                {pendingCount}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Nav strip */}
      <div className="flex lg:hidden items-center justify-around border-t border-slate-800/80 bg-slate-950 px-2 py-1.5 overflow-x-auto">
        <button
          onClick={() => setActiveTab('zoya')}
          className={`flex flex-col items-center py-1 px-2.5 text-[10px] font-semibold ${
            activeTab === 'zoya' ? 'text-pink-400' : 'text-slate-400'
          }`}
        >
          <Sparkles className="w-4 h-4 mb-0.5" />
          <span>Zoya</span>
        </button>
        <button
          onClick={() => setActiveTab('tasks')}
          className={`flex flex-col items-center py-1 px-2.5 text-[10px] font-medium ${
            activeTab === 'tasks' ? 'text-cyan-400' : 'text-slate-400'
          }`}
        >
          <ListTodo className="w-4 h-4 mb-0.5" />
          <span>Tasks</span>
        </button>
        <button
          onClick={() => setActiveTab('workflows')}
          className={`flex flex-col items-center py-1 px-2.5 text-[10px] font-medium ${
            activeTab === 'workflows' ? 'text-cyan-400' : 'text-slate-400'
          }`}
        >
          <Clock className="w-4 h-4 mb-0.5" />
          <span>Workflows</span>
        </button>
        <button
          onClick={() => setActiveTab('emulator')}
          className={`flex flex-col items-center py-1 px-2.5 text-[10px] font-medium ${
            activeTab === 'emulator' ? 'text-cyan-400' : 'text-slate-400'
          }`}
        >
          <Smartphone className="w-4 h-4 mb-0.5" />
          <span>Mobile</span>
        </button>
        <button
          onClick={() => setActiveTab('apk')}
          className={`flex flex-col items-center py-1 px-2.5 text-[10px] font-medium ${
            activeTab === 'apk' ? 'text-cyan-400' : 'text-slate-400'
          }`}
        >
          <Download className="w-4 h-4 mb-0.5" />
          <span>APK</span>
        </button>
        <button
          onClick={() => setActiveTab('api')}
          className={`flex flex-col items-center py-1 px-2.5 text-[10px] font-medium ${
            activeTab === 'api' ? 'text-cyan-400' : 'text-slate-400'
          }`}
        >
          <Terminal className="w-4 h-4 mb-0.5" />
          <span>APIs</span>
        </button>
      </div>
    </header>
  );
};
