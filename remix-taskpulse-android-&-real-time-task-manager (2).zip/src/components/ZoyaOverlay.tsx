import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  X,
  Volume2,
  VolumeX,
  PlusCircle,
  Clock,
  CheckCircle2,
  Minimize2,
  Maximize2,
  Zap,
  Target,
  Smile,
  Brain,
  Rocket,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Task, Priority } from '../types';
import { offlineStore } from '../lib/offlineStore';
import { notificationManager } from '../lib/notificationManager';

export type ZoyaMood = 'energetic' | 'focused' | 'cheerful' | 'thoughtful' | 'productive';

interface ChatMessage {
  id: string;
  sender: 'user' | 'zoya';
  text: string;
  time: string;
  taskData?: any;
}

interface ZoyaOverlayProps {
  currentTasks: Task[];
  onTaskCreated?: (task: Task) => void;
}

export const ZoyaOverlay: React.FC<ZoyaOverlayProps> = ({ currentTasks, onTaskCreated }) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [isMinimized, setIsMinimized] = useState<boolean>(false);
  const [mood, setMood] = useState<ZoyaMood>('cheerful');
  const [inputMessage, setInputMessage] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isVoiceEnabled, setIsVoiceEnabled] = useState<boolean>(true);
  const [bubbleText, setBubbleText] = useState<string>('Salam! Main Zoya hoon, aapki AI task partner ✨');
  const [showBubble, setShowBubble] = useState<boolean>(true);

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      sender: 'zoya',
      text: 'Salam! Main Zoya hoon, aapki smart Android task management agent! Main aapke tasks create kar sakti hoon, push reminders schedule kar sakti hoon aur productivity plan kar sakti hoon. Bolo kya madad chahiye?',
      time: 'Just now',
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  // Voice synthesis speaking Zoya's reply
  const speakText = (text: string) => {
    if (!isVoiceEnabled || typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.05;
      utterance.pitch = 1.15;
      const voices = window.speechSynthesis.getVoices();
      // Look for natural female English/Urdu voice
      const preferred = voices.find(
        (v) => (v.name.includes('Female') || v.name.includes('Samantha') || v.name.includes('Zira') || v.lang.startsWith('hi') || v.lang.startsWith('en'))
      );
      if (preferred) utterance.voice = preferred;
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      // ignore
    }
  };

  const getMoodBadge = (currentMood: ZoyaMood) => {
    switch (currentMood) {
      case 'energetic':
        return { label: 'Energetic', icon: Zap, color: 'text-amber-400 border-amber-500/50 bg-amber-950/40' };
      case 'focused':
        return { label: 'Focused', icon: Target, color: 'text-purple-400 border-purple-500/50 bg-purple-950/40' };
      case 'thoughtful':
        return { label: 'Thoughtful', icon: Brain, color: 'text-cyan-400 border-cyan-500/50 bg-cyan-950/40' };
      case 'productive':
        return { label: 'Productive', icon: Rocket, color: 'text-rose-400 border-rose-500/50 bg-rose-950/40' };
      case 'cheerful':
      default:
        return { label: 'Cheerful', icon: Smile, color: 'text-emerald-400 border-emerald-500/50 bg-emerald-950/40' };
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputMessage).trim();
    if (!text || isLoading) return;

    const userMsg: ChatMessage = {
      id: 'msg-' + Date.now(),
      sender: 'user',
      text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);
    setShowBubble(false);

    try {
      const res = await fetch('/api/zoya/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          currentTasks,
        }),
      });

      const data = await res.json();
      const zoyaReply = data.reply || 'Main samajh gayi! Chalein mil kar is task ko complete karte hain.';
      const newMood = (data.mood as ZoyaMood) || 'cheerful';
      setMood(newMood);
      setBubbleText(zoyaReply);

      const zoyaMsg: ChatMessage = {
        id: 'msg-zoya-' + Date.now(),
        sender: 'zoya',
        text: zoyaReply,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        taskData: data.taskData,
      };

      setMessages((prev) => [...prev, zoyaMsg]);
      speakText(zoyaReply);

      // If action is create_task and taskData is present, auto-create task or let user confirm
      if (data.action === 'create_task' && data.taskData) {
        handleAutoCreateTask(data.taskData);
      } else if (data.action === 'set_reminder') {
        const topTask = currentTasks[0];
        if (topTask) {
          notificationManager.triggerNotification(topTask, 'Zoya Scheduled Push Reminder Alert!');
        }
      }
    } catch (err) {
      const fallbackReply = 'Shukriya! Main ne aapki baat note kar li hai.';
      setMessages((prev) => [
        ...prev,
        {
          id: 'msg-zoya-fallback-' + Date.now(),
          sender: 'zoya',
          text: fallbackReply,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
      speakText(fallbackReply);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAutoCreateTask = (tData: any) => {
    const newTask = offlineStore.addTask({
      title: tData.title || 'Zoya Task',
      description: tData.description || 'Created by Zoya AI Agent',
      priority: (tData.priority as Priority) || 'high',
      status: 'todo',
      category: tData.category || 'cat-android',
      dueDate: new Date(Date.now() + 86400000).toISOString(),
      reminderTime: new Date(Date.now() + (tData.reminderMinutes || 30) * 60000).toISOString(),
      isCompleted: false,
      tags: ['zoya', 'agent'],
      subtasks: tData.subtasks || [
        { id: 'st-z1', title: 'Task plan review', completed: false },
        { id: 'st-z2', title: 'Execute with high focus', completed: false },
      ],
    });

    try {
      confetti({
        particleCount: 35,
        spread: 50,
        origin: { y: 0.8 },
        colors: ['#06b6d4', '#8b5cf6', '#10b981'],
      });
    } catch (e) {
      // ignore
    }

    if (onTaskCreated) onTaskCreated(newTask);
  };

  const moodInfo = getMoodBadge(mood);
  const MoodIcon = moodInfo.icon;

  return (
    <>
      {/* Floating Zoya Avatar Button on Phone Screen */}
      <div className="fixed bottom-14 right-4 sm:bottom-16 sm:right-6 z-40 flex flex-col items-end">
        {/* Proactive Speech Bubble (when collapsed) */}
        {!isOpen && showBubble && (
          <div
            onClick={() => setIsOpen(true)}
            className="mb-2 max-w-[240px] bg-slate-900/95 border border-cyan-500/40 text-slate-100 text-[11px] p-2.5 rounded-2xl rounded-br-sm shadow-2xl backdrop-blur-md cursor-pointer animate-in fade-in slide-in-from-bottom-2 duration-300 relative group hover:border-cyan-400"
          >
            <div className="flex items-center space-x-1.5 mb-1">
              <span className="font-bold text-cyan-400">Zoya (AI Agent)</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[9px] border font-semibold ${moodInfo.color}`}>
                {moodInfo.label}
              </span>
            </div>
            <p className="line-clamp-2 text-slate-200">{bubbleText}</p>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowBubble(false);
              }}
              className="absolute -top-1.5 -left-1.5 w-4 h-4 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center text-[10px]"
            >
              ×
            </button>
          </div>
        )}

        {/* Circular Avatar Trigger */}
        <div className="relative group">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="w-13 h-13 rounded-full bg-gradient-to-tr from-cyan-500 via-indigo-600 to-pink-500 p-0.5 shadow-xl shadow-cyan-500/30 hover:scale-105 active:scale-95 transition-all flex items-center justify-center"
            title="Chat with Zoya AI Agent"
          >
            <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center relative overflow-hidden">
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-cyan-400/20 to-pink-500/30 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-cyan-300 animate-pulse" />
              </div>

              {/* Mood indicator dot */}
              <div className="absolute bottom-0.5 right-0.5 w-3 h-3 rounded-full bg-emerald-400 border-2 border-slate-950" />
            </div>
          </button>

          <span className="absolute -top-1 -right-1 px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-cyan-500 text-slate-950 shadow-sm uppercase tracking-wider">
            Zoya
          </span>
        </div>
      </div>

      {/* Expanded Zoya Chat Drawer / Window */}
      {isOpen && (
        <div className="fixed inset-x-3 bottom-4 sm:inset-auto sm:right-6 sm:bottom-20 z-50 w-auto sm:w-[380px] h-[520px] rounded-3xl bg-slate-900/95 border border-cyan-500/40 shadow-2xl backdrop-blur-xl flex flex-col overflow-hidden text-slate-100 animate-in slide-in-from-bottom-4 duration-200">
          {/* Header */}
          <div className="px-4 py-3 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center space-x-2.5">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-500 to-pink-500 flex items-center justify-center p-0.5 shadow-md">
                <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                </div>
              </div>
              <div>
                <div className="flex items-center space-x-1.5">
                  <h3 className="text-xs font-bold text-white">Zoya AI Agent</h3>
                  <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-semibold border flex items-center space-x-1 ${moodInfo.color}`}>
                    <MoodIcon className="w-2.5 h-2.5" />
                    <span>{moodInfo.label}</span>
                  </span>
                </div>
                <p className="text-[10px] text-slate-400">Urdu & English Task Assistant</p>
              </div>
            </div>

            <div className="flex items-center space-x-1">
              <button
                onClick={() => setIsVoiceEnabled(!isVoiceEnabled)}
                className={`p-1 rounded-lg text-xs ${isVoiceEnabled ? 'text-cyan-400' : 'text-slate-500'} hover:bg-slate-800`}
                title={isVoiceEnabled ? 'Mute Voice' : 'Unmute Voice'}
              >
                {isVoiceEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Quick Prompt Chips */}
          <div className="px-3 py-2 bg-slate-950/60 border-b border-slate-800/80 flex items-center space-x-1.5 overflow-x-auto custom-scrollbar text-[10px]">
            <button
              onClick={() => handleSendMessage('Zoya, naya urgent task banao for Android APK')}
              className="px-2 py-1 rounded-lg bg-cyan-950/60 text-cyan-300 border border-cyan-800/60 whitespace-nowrap hover:bg-cyan-900/60"
            >
              ⚡ Urgent Task Banao
            </button>
            <button
              onClick={() => handleSendMessage('Aaj ke pending tasks ka summary batao')}
              className="px-2 py-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700 whitespace-nowrap hover:bg-slate-700"
            >
              📋 Aaj Ka Summary
            </button>
            <button
              onClick={() => handleSendMessage('1 ghante baad ka push reminder schedule karo')}
              className="px-2 py-1 rounded-lg bg-amber-950/60 text-amber-300 border border-amber-800/60 whitespace-nowrap hover:bg-amber-900/60"
            >
              🔔 1h Reminder
            </button>
          </div>

          {/* Messages Scroll Area */}
          <div className="flex-1 overflow-y-auto p-3.5 space-y-3 custom-scrollbar text-xs">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 leading-relaxed shadow-md ${
                    m.sender === 'user'
                      ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-br-sm'
                      : 'bg-slate-800/90 border border-slate-700/80 text-slate-200 rounded-bl-sm'
                  }`}
                >
                  <p>{m.text}</p>

                  {/* If Zoya proposed an actionable task card */}
                  {m.taskData && (
                    <div className="mt-2.5 pt-2 border-t border-slate-700/80 bg-slate-950/60 p-2 rounded-xl text-[11px]">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-cyan-300">{m.taskData.title}</span>
                        <span className="text-[9px] uppercase font-bold px-1 rounded bg-rose-950 text-rose-400">
                          {m.taskData.priority}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-400 line-clamp-1">{m.taskData.description}</p>
                      <button
                        onClick={() => handleAutoCreateTask(m.taskData)}
                        className="mt-2 w-full py-1 rounded-lg bg-cyan-500 text-slate-950 font-bold text-[10px] flex items-center justify-center space-x-1 hover:bg-cyan-400 transition-colors"
                      >
                        <PlusCircle className="w-3 h-3" />
                        <span>Task Add Karo (+ Instant Sync)</span>
                      </button>
                    </div>
                  )}
                </div>
                <span className="text-[9px] text-slate-500 mt-0.5 px-1">{m.time}</span>
              </div>
            ))}

            {isLoading && (
              <div className="flex items-center space-x-2 text-slate-400 text-xs pl-2">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                <span>Zoya soch rahi hai...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Footer */}
          <div className="p-3 bg-slate-950/90 border-t border-slate-800">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center space-x-2"
            >
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Zoya se baat karein... (e.g. 'Task banao')"
                className="flex-1 bg-slate-900 border border-slate-800 focus:border-cyan-500 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none"
              />
              <button
                type="submit"
                disabled={isLoading || !inputMessage.trim()}
                className="p-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-40 transition-all shadow-md shadow-cyan-500/20"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
