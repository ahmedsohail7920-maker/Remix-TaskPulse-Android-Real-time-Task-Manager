import React, { useState } from 'react';
import {
  ShieldAlert,
  CheckCircle,
  XCircle,
  Mail,
  MessageSquare,
  AlertTriangle,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';
import { PendingToolApproval, ToolExecutionResult } from '../lib/zoyaTools';

interface ZoyaApprovalModalProps {
  approvals: PendingToolApproval[];
}

export const ZoyaApprovalModal: React.FC<ZoyaApprovalModalProps> = ({ approvals }) => {
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [lastExecutedResult, setLastExecutedResult] = useState<ToolExecutionResult | null>(null);

  if (approvals.length === 0 && !lastExecutedResult) return null;

  const currentApproval = approvals[0];

  const handleApprove = async () => {
    if (!currentApproval || isProcessing) return;
    setIsProcessing(true);
    try {
      const result = await currentApproval.onApprove();
      setLastExecutedResult(result);
      setTimeout(() => {
        setLastExecutedResult(null);
      }, 4000);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleReject = () => {
    if (!currentApproval || isProcessing) return;
    currentApproval.onReject();
  };

  // If showing verified result banner
  if (lastExecutedResult) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
        <div className="max-w-md w-full rounded-3xl bg-slate-900 border border-emerald-500/50 p-6 text-slate-100 shadow-2xl">
          <div className="flex items-center space-x-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <CheckCircle className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-400">
                Action Verified
              </span>
              <h3 className="text-base font-bold text-white">Execution Succeeded</h3>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed mb-4">
            {lastExecutedResult.statusText}
          </p>

          {lastExecutedResult.verificationEvidence && (
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-slate-400 space-y-1 mb-4">
              <span className="text-slate-500 block text-[10px]">Verification Evidence:</span>
              <pre className="text-emerald-300 overflow-x-auto">
                {JSON.stringify(lastExecutedResult.verificationEvidence, null, 2)}
              </pre>
            </div>
          )}

          <button
            onClick={() => setLastExecutedResult(null)}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition-colors"
          >
            Dismiss
          </button>
        </div>
      </div>
    );
  }

  const isEmail = currentApproval.toolName.includes('gmail');
  const isWhatsApp = currentApproval.toolName.includes('whatsapp');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="max-w-lg w-full rounded-3xl bg-slate-900 border-2 border-amber-500/60 p-6 text-slate-100 shadow-2xl">
        {/* Header Warning */}
        <div className="flex items-start space-x-3 mb-4">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
            {isEmail ? (
              <Mail className="w-5 h-5" />
            ) : isWhatsApp ? (
              <MessageSquare className="w-5 h-5 text-emerald-400" />
            ) : (
              <ShieldAlert className="w-5 h-5" />
            )}
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-950 text-amber-400 border border-amber-800">
                Mandatory Approval Required
              </span>
              <span className="text-[11px] font-mono text-slate-400">{currentApproval.toolName}</span>
            </div>
            <h3 className="text-base font-bold text-white mt-1">{currentApproval.actionTitle}</h3>
          </div>
        </div>

        {/* Action Description */}
        <p className="text-xs text-slate-300 leading-relaxed mb-4">
          {currentApproval.description}
        </p>

        {/* Payload Preview */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 mb-5 space-y-2 text-xs">
          {isEmail && (
            <>
              <div>
                <span className="text-slate-500">To: </span>
                <span className="font-semibold text-slate-200">{currentApproval.payload.to}</span>
              </div>
              <div>
                <span className="text-slate-500">Subject: </span>
                <span className="font-semibold text-cyan-300">{currentApproval.payload.subject}</span>
              </div>
              <div className="pt-2 border-t border-slate-800/80">
                <span className="text-slate-500 block mb-1">Email Body:</span>
                <p className="text-slate-300 bg-slate-900 p-2.5 rounded-xl whitespace-pre-wrap font-sans text-xs">
                  {currentApproval.payload.body}
                </p>
              </div>
            </>
          )}

          {isWhatsApp && (
            <>
              <div>
                <span className="text-slate-500">Recipient Phone: </span>
                <span className="font-semibold font-mono text-emerald-300">{currentApproval.payload.phone}</span>
              </div>
              <div className="pt-2 border-t border-slate-800/80">
                <span className="text-slate-500 block mb-1">WhatsApp Message:</span>
                <p className="text-slate-200 bg-slate-900 p-2.5 rounded-xl whitespace-pre-wrap font-sans text-xs border border-emerald-950">
                  {currentApproval.payload.message}
                </p>
              </div>
            </>
          )}

          {!isEmail && !isWhatsApp && (
            <pre className="font-mono text-slate-300 text-[11px] overflow-x-auto">
              {JSON.stringify(currentApproval.payload, null, 2)}
            </pre>
          )}
        </div>

        {/* Security Assurance Notice */}
        <div className="flex items-center space-x-2 text-[11px] text-slate-400 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 mb-5">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>
            Zoya will not claim success until verification evidence is confirmed from the target service.
          </span>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end space-x-3">
          <button
            onClick={handleReject}
            disabled={isProcessing}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            Reject & Cancel
          </button>
          <button
            onClick={handleApprove}
            disabled={isProcessing}
            className="px-5 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 hover:from-emerald-400 hover:to-cyan-400 shadow-lg shadow-emerald-500/20 active:scale-95 transition-all flex items-center space-x-1.5"
          >
            <span>{isProcessing ? 'Verifying & Executing...' : 'Approve & Execute Action'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
