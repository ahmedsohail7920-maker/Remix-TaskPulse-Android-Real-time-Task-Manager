/**
 * Zoya AI: Interactive Animated Floating Character with Expressive Emotional States
 * Displays the anime AI companion Zoya floating on screen with smooth levitation physics,
 * reactive glow rings, bilingual Roman Urdu voice lines, and interactive emotion switching.
 */
import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Mic,
  MicOff,
  Zap,
  Volume2,
  VolumeX,
  Smile,
  Headphones,
  Brain,
  PartyPopper,
  Move,
  MessageCircle,
  X,
  ChevronUp,
  ChevronDown,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { speechService, SpeechRecognitionResultPayload } from '../lib/speechService';
import { zoyaToolRegistry } from '../lib/zoyaTools';
import { Task } from '../types';

export type ZoyaEmotion = 'happy' | 'listening' | 'thinking' | 'excited';

export interface EmotionConfig {
  id: ZoyaEmotion;
  label: string;
  urduLabel: string;
  imageSrc: string;
  description: string;
  auraGradient: string;
  badgeBg: string;
  badgeText: string;
  voiceLines: string[];
}

export const ZOYA_EMOTIONS: Record<ZoyaEmotion, EmotionConfig> = {
  happy: {
    id: 'happy',
    label: 'Happy / Ready',
    urduLabel: 'Khush & Taiyyar',
    imageSrc: '/src/assets/images/zoya_happy_1791901195473.jpg',
    description: 'Friendly warm smile, cyan-violet cyber aura',
    auraGradient: 'from-cyan-400 via-purple-500 to-pink-500',
    badgeBg: 'bg-cyan-500/20 border-cyan-400/40',
    badgeText: 'text-cyan-300',
    voiceLines: [
      'Salam Janab! Main Zoya hoon, aapki personal voice assistant ✨',
      'Ji bolo, aaj aapka kaunsa kaam automate karna hai?',
      'Main har waqt aapke sath hoon, bas ek hukum ki dair hai!',
    ],
  },
  listening: {
    id: 'listening',
    label: 'Listening',
    urduLabel: 'Sunti Hui',
    imageSrc: '/src/assets/images/zoya_listening_1791901195977.jpg',
    description: 'Headset active, listening attentively to your voice',
    auraGradient: 'from-cyan-400 via-emerald-400 to-teal-400',
    badgeBg: 'bg-emerald-500/20 border-emerald-400/40',
    badgeText: 'text-emerald-300',
    voiceLines: [
      'Bolo, main dhyan se sun rahi hoon...',
      'Aapki aawaz clearly receive ho rahi hai, farmayiye.',
      'Main Roman Urdu aur English dono samajhti hoon, bolo!',
    ],
  },
  thinking: {
    id: 'thinking',
    label: 'Thinking / AI',
    urduLabel: 'Soch Rahi Hoon',
    imageSrc: '/src/assets/images/zoya_thinking_1791901195947.jpg',
    description: 'Processing neural stream & analyzing multi-step tasks',
    auraGradient: 'from-purple-500 via-fuchsia-500 to-indigo-500',
    badgeBg: 'bg-purple-500/20 border-purple-400/40',
    badgeText: 'text-purple-300',
    voiceLines: [
      'Ek minute, main smart steps generate kar rahi hoon...',
      'Gemini AI engine task process kar raha hai, thora sa intezar karein.',
      'Analyzing best automated workflow for you...',
    ],
  },
  excited: {
    id: 'excited',
    label: 'Excited / Done',
    urduLabel: 'Wah! Zabardast',
    imageSrc: '/src/assets/images/zoya_excited_1791901196157.jpg',
    description: 'Celebratory wink with sparkling energy aura',
    auraGradient: 'from-amber-400 via-rose-500 to-pink-500',
    badgeBg: 'bg-amber-500/20 border-amber-400/40',
    badgeText: 'text-amber-300',
    voiceLines: [
      'Wah! Kamaal ho gaya! Aapka task kamyabi se poora hua 🎉',
      'Zabardast! Saare tasks auto-schedule aur cloud sync ho chuke hain!',
      'Mission accomplished! Bolo agla hukum kya hai?',
    ],
  },
};

interface ZoyaFloatingCharacterProps {
  currentTasks: Task[];
  onOpenAssistantModal?: () => void;
  externalEmotion?: ZoyaEmotion;
  onEmotionChange?: (emotion: ZoyaEmotion) => void;
}

export const ZoyaFloatingCharacter: React.FC<ZoyaFloatingCharacterProps> = ({
  currentTasks,
  onOpenAssistantModal,
  externalEmotion,
  onEmotionChange,
}) => {
  // Draggable Coordinates (Positioned safely on bottom-right by default)
  const [position, setPosition] = useState<{ x: number; y: number }>(() => {
    if (typeof window !== 'undefined') {
      return {
        x: Math.max(20, window.innerWidth - 220),
        y: Math.max(80, window.innerHeight - 340),
      };
    }
    return { x: 750, y: 350 };
  });

  const [isDragging, setIsDragging] = useState<boolean>(false);
  const dragStartRef = useRef<{ startX: number; startY: number; posX: number; posY: number }>({
    startX: 0,
    startY: 0,
    posX: 0,
    posY: 0,
  });

  // Emotional & Interactive State
  const [emotion, setEmotion] = useState<ZoyaEmotion>('happy');
  const [isFloating, setIsFloating] = useState<boolean>(true);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [voiceEnabled, setVoiceEnabled] = useState<boolean>(true);
  const [speechBubbleText, setSpeechBubbleText] = useState<string>(
    'Salam! Main Zoya hoon ✨ Touch karke mujhse baat karo!'
  );
  const [showSpeechBubble, setShowSpeechBubble] = useState<boolean>(true);
  const [showEmotionMenu, setShowEmotionMenu] = useState<boolean>(false);
  const [isAutoRunning, setIsAutoRunning] = useState<boolean>(false);
  const [isCompact, setIsCompact] = useState<boolean>(false);

  // Sync external emotion if passed
  useEffect(() => {
    if (externalEmotion && externalEmotion !== emotion) {
      setEmotion(externalEmotion);
    }
  }, [externalEmotion]);

  const activeEmotionConfig = ZOYA_EMOTIONS[emotion];

  // Dragging Handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button, input, a, select')) return;
    setIsDragging(true);
    dragStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      posX: position.x,
      posY: position.y,
    };
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if ((e.target as HTMLElement).closest('button, input, a, select')) return;
    setIsDragging(true);
    const touch = e.touches[0];
    dragStartRef.current = {
      startX: touch.clientX,
      startY: touch.clientY,
      posX: position.x,
      posY: position.y,
    };
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const dx = e.clientX - dragStartRef.current.startX;
      const dy = e.clientY - dragStartRef.current.startY;
      const maxW = isCompact ? 100 : 220;
      const maxH = isCompact ? 100 : 340;
      const newX = Math.max(10, Math.min(window.innerWidth - maxW, dragStartRef.current.posX + dx));
      const newY = Math.max(10, Math.min(window.innerHeight - maxH, dragStartRef.current.posY + dy));
      setPosition({ x: newX, y: newY });
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!isDragging) return;
      const touch = e.touches[0];
      const dx = touch.clientX - dragStartRef.current.startX;
      const dy = touch.clientY - dragStartRef.current.startY;
      const maxW = isCompact ? 100 : 220;
      const maxH = isCompact ? 100 : 340;
      const newX = Math.max(10, Math.min(window.innerWidth - maxW, dragStartRef.current.posX + dx));
      const newY = Math.max(10, Math.min(window.innerHeight - maxH, dragStartRef.current.posY + dy));
      setPosition({ x: newX, y: newY });
    };

    const handleEnd = () => setIsDragging(false);

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleEnd);
      window.addEventListener('touchmove', handleTouchMove);
      window.addEventListener('touchend', handleEnd);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleEnd);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleEnd);
    };
  }, [isDragging, isCompact]);

  // Handle Character Click / Tap to Trigger Dialogue & Emotion
  const handleCharacterClick = () => {
    if (isDragging) return;

    // Pick random voice line for current emotion
    const lines = activeEmotionConfig.voiceLines;
    const randomLine = lines[Math.floor(Math.random() * lines.length)];
    setSpeechBubbleText(randomLine);
    setShowSpeechBubble(true);

    if (voiceEnabled) {
      setIsSpeaking(true);
      speechService.speak(randomLine, () => {
        setIsSpeaking(false);
      });
    }
  };

  // Switch emotion manually
  const switchEmotion = (newEmotion: ZoyaEmotion) => {
    setEmotion(newEmotion);
    onEmotionChange?.(newEmotion);
    setShowEmotionMenu(false);

    const config = ZOYA_EMOTIONS[newEmotion];
    const phrase = config.voiceLines[0];
    setSpeechBubbleText(phrase);
    setShowSpeechBubble(true);

    if (newEmotion === 'excited') {
      try {
        confetti({
          particleCount: 40,
          spread: 60,
          origin: {
            x: position.x / window.innerWidth,
            y: position.y / window.innerHeight,
          },
        });
      } catch (e) {
        // ignore
      }
    }

    if (voiceEnabled) {
      setIsSpeaking(true);
      speechService.speak(phrase, () => setIsSpeaking(false));
    }
  };

  // Toggle Voice Listening directly on character
  const handleToggleMic = () => {
    if (isListening) {
      speechService.stopListening();
      setIsListening(false);
      switchEmotion('happy');
    } else {
      switchEmotion('listening');
      setSpeechBubbleText('Main sun rahi hoon... Boliye!');
      const started = speechService.startListening(
        (res: SpeechRecognitionResultPayload) => {
          setSpeechBubbleText(res.transcript);
          if (res.isFinal) {
            speechService.stopListening();
            setIsListening(false);
            switchEmotion('thinking');
            processVoiceCommand(res.transcript);
          }
        },
        (listening: boolean) => setIsListening(listening)
      );

      if (!started) {
        setSpeechBubbleText('Microphone access restricted in iframe. Type command instead!');
        switchEmotion('happy');
      }
    }
  };

  // Simple quick command handler
  const processVoiceCommand = async (cmd: string) => {
    const text = cmd.toLowerCase();
    setSpeechBubbleText(`"${cmd}" - Processing with Gemini AI...`);

    if (text.includes('auto') || text.includes('kam') || text.includes('task')) {
      handleRunAutoPilot();
      return;
    }

    setTimeout(() => {
      switchEmotion('excited');
      const reply = `Zoya: "${cmd}" note kar liya hai! Sab theek se organize ho gaya!`;
      setSpeechBubbleText(reply);
      if (voiceEnabled) {
        setIsSpeaking(true);
        speechService.speak(reply, () => {
          setIsSpeaking(false);
          setTimeout(() => switchEmotion('happy'), 4000);
        });
      }
    }, 1200);
  };

  // Run 1-Click Auto Pilot from Character
  const handleRunAutoPilot = async () => {
    setIsAutoRunning(true);
    switchEmotion('thinking');
    const intro = 'Auto-Pilot activate ho raha hai! Saare pending tasks optimize kiye ja rahe hain.';
    setSpeechBubbleText(intro);
    if (voiceEnabled) {
      speechService.speak(intro);
    }

    try {
      const res = await zoyaToolRegistry.executeAutoPilot(currentTasks);
      switchEmotion('excited');
      const successMsg = `Zabardast! ${res.statusText} Saare tasks verify ho chuke hain! 🎉`;
      setSpeechBubbleText(successMsg);
      try {
        confetti({
          particleCount: 60,
          spread: 80,
          origin: {
            x: position.x / window.innerWidth,
            y: position.y / window.innerHeight,
          },
        });
      } catch (e) {
        // ignore
      }
      if (voiceEnabled) {
        setIsSpeaking(true);
        speechService.speak(successMsg, () => {
          setIsSpeaking(false);
        });
      }
    } catch (err) {
      switchEmotion('happy');
      setSpeechBubbleText('Task process complete ho gaya!');
    } finally {
      setIsAutoRunning(false);
    }
  };

  return (
    <div
      style={{ left: `${position.x}px`, top: `${position.y}px` }}
      onMouseDown={handleMouseDown}
      onTouchStart={handleTouchStart}
      className={`fixed z-50 select-none cursor-grab active:cursor-grabbing transition-transform duration-100 ${
        isFloating ? 'animate-zoya-float' : ''
      }`}
    >
      {/* Comic Speech Bubble */}
      {showSpeechBubble && (
        <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-52 sm:w-60 p-2.5 rounded-2xl bg-slate-900/95 border border-cyan-400/60 shadow-2xl backdrop-blur-md text-slate-100 text-[11px] leading-tight animate-in fade-in zoom-in-95 pointer-events-auto">
          <div className="flex items-center justify-between mb-1 pb-1 border-b border-slate-800">
            <span className="flex items-center space-x-1 text-cyan-300 font-bold text-[10px]">
              <Sparkles className="w-3 h-3 text-cyan-400" />
              <span>Zoya ({activeEmotionConfig.urduLabel})</span>
            </span>
            <button
              onClick={() => setShowSpeechBubble(false)}
              className="text-slate-400 hover:text-white p-0.5"
            >
              <X className="w-2.5 h-2.5" />
            </button>
          </div>
          <p className="text-slate-200 line-clamp-2">{speechBubbleText}</p>
          {/* Comic Bubble Arrow */}
          <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-slate-900 border-r border-b border-cyan-400/60 rotate-45" />
        </div>
      )}

      {/* Main Avatar Character Frame */}
      <div className="relative group">
        {/* Animated Radiant Aura Ring */}
        <div
          className={`absolute -inset-2 rounded-3xl bg-gradient-to-tr ${activeEmotionConfig.auraGradient} opacity-70 blur-md group-hover:opacity-100 transition-all duration-500 ${
            isSpeaking || isListening ? 'animate-pulse scale-105' : ''
          }`}
        />

        {/* Outer Glow Wave during speech/listening */}
        {(isSpeaking || isListening) && (
          <div
            className={`absolute -inset-4 rounded-3xl border-2 border-cyan-400/60 animate-zoya-wave pointer-events-none`}
          />
        )}

        {/* Character Card Container */}
        <div className="relative w-36 sm:w-40 rounded-3xl bg-slate-950/90 border-2 border-cyan-500/60 shadow-2xl overflow-hidden backdrop-blur-xl">
          {/* Top Status Handle */}
          <div className="px-2.5 py-1.5 bg-slate-950/90 border-b border-slate-800/80 flex items-center justify-between text-[10px]">
            <span className="flex items-center space-x-1 font-bold text-white tracking-wide">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>Zoya AI</span>
            </span>
            <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-bold border ${activeEmotionConfig.badgeBg} ${activeEmotionConfig.badgeText}`}>
              {activeEmotionConfig.urduLabel}
            </span>
          </div>

          {/* Interactive Anime Character Image */}
          <div
            onClick={handleCharacterClick}
            className="relative w-full aspect-square overflow-hidden cursor-pointer group/img"
            title="Click to talk with Zoya!"
          >
            <img
              src={activeEmotionConfig.imageSrc}
              alt={`Zoya AI - ${activeEmotionConfig.label}`}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center transition-transform duration-500 group-hover/img:scale-110"
            />

            {/* Subtle Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-60" />

            {/* Sound Wave Indicators during speaking */}
            {isSpeaking && (
              <div className="absolute bottom-2 left-2 right-2 flex items-center justify-center space-x-1 bg-slate-950/80 backdrop-blur-sm py-0.5 px-2 rounded-full border border-cyan-500/40">
                <span className="w-1 h-3 bg-cyan-400 rounded-full animate-bounce" />
                <span className="w-1 h-5 bg-pink-400 rounded-full animate-bounce [animation-delay:150ms]" />
                <span className="w-1 h-2 bg-purple-400 rounded-full animate-bounce [animation-delay:300ms]" />
                <span className="text-[9px] text-cyan-300 font-bold ml-1">Bol Rahi Hoon...</span>
              </div>
            )}

            {/* Listening Wave Indicator */}
            {isListening && (
              <div className="absolute bottom-2 left-2 right-2 flex items-center justify-center space-x-1 bg-emerald-950/90 backdrop-blur-sm py-0.5 px-2 rounded-full border border-emerald-500/50">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping mr-1" />
                <span className="text-[9px] text-emerald-300 font-bold">Sun Rahi Hoon...</span>
              </div>
            )}
          </div>

          {/* Floating Action Buttons Toolbar */}
          <div className="p-1.5 bg-slate-950 border-t border-slate-800/80 flex items-center justify-around text-slate-300">
            {/* Mic Button */}
            <button
              onClick={handleToggleMic}
              className={`p-1.5 rounded-xl transition-all ${
                isListening
                  ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/50 scale-110'
                  : 'bg-slate-900 hover:bg-slate-800 text-cyan-400 hover:text-cyan-300'
              }`}
              title={isListening ? 'Stop Listening' : 'Speak to Zoya (Roman Urdu / English)'}
            >
              {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
            </button>

            {/* 1-Click Auto-Pilot Button */}
            <button
              onClick={handleRunAutoPilot}
              disabled={isAutoRunning}
              className="p-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-rose-500 text-slate-950 hover:brightness-110 font-bold shadow-md shadow-amber-500/20 active:scale-95 transition-all"
              title="1-Click Auto-Pilot: Execute & auto-schedule all tasks"
            >
              <Zap className={`w-3.5 h-3.5 ${isAutoRunning ? 'animate-spin' : ''}`} />
            </button>

            {/* Open Full Assistant Chat Cockpit */}
            {onOpenAssistantModal && (
              <button
                onClick={onOpenAssistantModal}
                className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-cyan-400 hover:text-cyan-300"
                title="Open Zoya AI Chat Cockpit"
              >
                <MessageCircle className="w-3.5 h-3.5" />
              </button>
            )}

            {/* Emotion Selector Toggle */}
            <button
              onClick={() => setShowEmotionMenu(!showEmotionMenu)}
              className={`p-1.5 rounded-xl transition-all ${
                showEmotionMenu
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-slate-900 hover:bg-slate-800 text-purple-400'
              }`}
              title="Change Zoya's Emotion & Mood"
            >
              <Smile className="w-3.5 h-3.5" />
            </button>

            {/* TTS Sound Mute/Unmute */}
            <button
              onClick={() => {
                if (voiceEnabled && isSpeaking) {
                  speechService.stopSpeaking();
                  setIsSpeaking(false);
                }
                setVoiceEnabled(!voiceEnabled);
              }}
              className={`p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 ${
                voiceEnabled ? 'text-cyan-400' : 'text-slate-500'
              }`}
              title={voiceEnabled ? 'Mute Voice' : 'Enable Voice Output'}
            >
              {voiceEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            </button>

            {/* Float Toggle */}
            <button
              onClick={() => setIsFloating(!isFloating)}
              className={`p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 ${
                isFloating ? 'text-emerald-400' : 'text-slate-500'
              }`}
              title={isFloating ? 'Pause Floating Motion' : 'Enable Floating Motion'}
            >
              <Move className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Emotions Selection Popover Menu */}
        {showEmotionMenu && (
          <div className="absolute -top-36 left-0 right-0 p-2 rounded-2xl bg-slate-900/95 border border-purple-500/60 shadow-2xl backdrop-blur-xl space-y-1 animate-in fade-in zoom-in-95 pointer-events-auto">
            <div className="text-[10px] font-bold text-purple-300 px-1 mb-1 flex items-center justify-between">
              <span>Zoya Emotions (Must)</span>
              <button onClick={() => setShowEmotionMenu(false)} className="text-slate-400 hover:text-white">
                <X className="w-2.5 h-2.5" />
              </button>
            </div>
            {(Object.keys(ZOYA_EMOTIONS) as ZoyaEmotion[]).map((emoKey) => {
              const cfg = ZOYA_EMOTIONS[emoKey];
              const isCurrent = emotion === emoKey;
              return (
                <button
                  key={emoKey}
                  onClick={() => switchEmotion(emoKey)}
                  className={`w-full text-left px-2 py-1 rounded-lg text-[10px] font-semibold flex items-center justify-between transition-colors ${
                    isCurrent
                      ? 'bg-purple-600/40 text-purple-200 border border-purple-400/50'
                      : 'hover:bg-slate-800 text-slate-300'
                  }`}
                >
                  <span className="flex items-center space-x-1.5">
                    {emoKey === 'happy' && <span>😊</span>}
                    {emoKey === 'listening' && <span>🎧</span>}
                    {emoKey === 'thinking' && <span>💡</span>}
                    {emoKey === 'excited' && <span>✨</span>}
                    <span>{cfg.urduLabel}</span>
                  </span>
                  <span className="text-[9px] text-slate-400">{cfg.label}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
