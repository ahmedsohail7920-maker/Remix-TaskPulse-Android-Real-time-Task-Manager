import React from 'react';
import {
  Check,
  Clock,
  Bell,
  Trash2,
  Edit3,
  CloudCheck,
  CloudOff,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Task, Priority } from '../types';

interface TaskCardProps {
  task: Task;
  onToggleComplete: (id: string) => void;
  onEdit: (task: Task) => void;
  onDelete: (id: string) => void;
  onToggleSubtask: (taskId: string, subtaskId: string) => void;
}

export const TaskCard: React.FC<TaskCardProps> = ({
  task,
  onToggleComplete,
  onEdit,
  onDelete,
  onToggleSubtask,
}) => {
  const [showSubtasks, setShowSubtasks] = React.useState<boolean>(false);

  const handleCheck = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!task.isCompleted) {
      try {
        confetti({
          particleCount: 40,
          spread: 60,
          origin: { y: 0.7 },
          colors: ['#06b6d4', '#10b981', '#8b5cf6'],
        });
      } catch (err) {
        // ignore
      }
    }
    onToggleComplete(task.id);
  };

  const getPriorityBadge = (priority: Priority) => {
    switch (priority) {
      case 'urgent':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wide uppercase bg-rose-950/80 text-rose-400 border border-rose-800/80 flex items-center space-x-1">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
            <span>Urgent</span>
          </span>
        );
      case 'high':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold tracking-wide uppercase bg-amber-950/70 text-amber-400 border border-amber-800/60">
            High
          </span>
        );
      case 'medium':
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold tracking-wide uppercase bg-cyan-950/70 text-cyan-400 border border-cyan-800/60">
            Medium
          </span>
        );
      case 'low':
      default:
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-medium tracking-wide uppercase bg-slate-900 text-slate-400 border border-slate-800">
            Low
          </span>
        );
    }
  };

  const formatDueDate = (dateStr?: string) => {
    if (!dateStr) return null;
    const date = new Date(dateStr);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    const isPast = date.getTime() < now.getTime() && !task.isCompleted;

    const timeFormatted = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    if (isToday) {
      return (
        <span className={`flex items-center space-x-1 ${isPast ? 'text-rose-400' : 'text-cyan-400'}`}>
          <Clock className="w-3 h-3" />
          <span>Today, {timeFormatted}</span>
        </span>
      );
    }
    return (
      <span className={`flex items-center space-x-1 ${isPast ? 'text-rose-400' : 'text-slate-400'}`}>
        <Clock className="w-3 h-3" />
        <span>{date.toLocaleDateString([], { month: 'short', day: 'numeric' })}, {timeFormatted}</span>
      </span>
    );
  };

  const completedSubtasks = task.subtasks?.filter((s) => s.completed).length || 0;
  const totalSubtasks = task.subtasks?.length || 0;

  return (
    <div
      className={`group relative rounded-2xl p-4 transition-all duration-200 border ${
        task.isCompleted
          ? 'bg-slate-950/60 border-slate-900 opacity-70'
          : 'bg-slate-900/90 hover:bg-slate-900 border-slate-800/90 hover:border-slate-700 shadow-md hover:shadow-cyan-950/20'
      }`}
    >
      <div className="flex items-start space-x-3">
        {/* Checkbox */}
        <button
          onClick={handleCheck}
          className={`mt-0.5 w-5 h-5 rounded-lg flex items-center justify-center transition-all ${
            task.isCompleted
              ? 'bg-emerald-500 text-slate-950 border border-emerald-400 shadow-sm shadow-emerald-500/30'
              : 'border-2 border-slate-600 hover:border-cyan-400 bg-slate-950/60'
          }`}
        >
          {task.isCompleted && <Check className="w-3.5 h-3.5 stroke-[3]" />}
        </button>

        {/* Task Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h3
              onClick={() => onEdit(task)}
              className={`text-sm font-semibold tracking-tight cursor-pointer hover:text-cyan-300 transition-colors ${
                task.isCompleted ? 'line-through text-slate-500' : 'text-slate-100'
              }`}
            >
              {task.title}
            </h3>

            {/* Sync and Priority Badges */}
            <div className="flex items-center space-x-1.5 shrink-0">
              {task._synced === false ? (
                <span title="Pending offline sync" className="text-amber-400">
                  <CloudOff className="w-3.5 h-3.5" />
                </span>
              ) : (
                <span title="Synced with Firestore" className="text-emerald-500/80">
                  <CloudCheck className="w-3.5 h-3.5" />
                </span>
              )}
              {getPriorityBadge(task.priority)}
            </div>
          </div>

          {/* Description */}
          {task.description && (
            <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
              {task.description}
            </p>
          )}

          {/* Metadata Row: Due Date, Reminder, Subtasks, Tags */}
          <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
            {formatDueDate(task.dueDate)}

            {task.reminderTime && (
              <span className="flex items-center space-x-1 text-amber-400/90 bg-amber-950/30 px-2 py-0.5 rounded-md border border-amber-800/40 text-[11px]">
                <Bell className="w-3 h-3" />
                <span>
                  {new Date(task.reminderTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </span>
            )}

            {totalSubtasks > 0 && (
              <button
                onClick={() => setShowSubtasks(!showSubtasks)}
                className="flex items-center space-x-1 text-slate-400 hover:text-cyan-300 bg-slate-950/80 px-2 py-0.5 rounded-md border border-slate-800 text-[11px] transition-colors"
              >
                <span>{completedSubtasks}/{totalSubtasks} subtasks</span>
                {showSubtasks ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              </button>
            )}

            {task.tags && task.tags.length > 0 && (
              <div className="flex items-center gap-1">
                {task.tags.map((tag) => (
                  <span
                    key={tag}
                    className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700/60"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Collapsible Subtasks Checklist */}
          {showSubtasks && totalSubtasks > 0 && (
            <div className="mt-3 pt-2.5 border-t border-slate-800/80 space-y-1.5">
              {task.subtasks?.map((st) => (
                <div
                  key={st.id}
                  onClick={() => onToggleSubtask(task.id, st.id)}
                  className="flex items-center space-x-2 text-xs py-1 px-2 rounded-lg hover:bg-slate-950/60 cursor-pointer transition-colors"
                >
                  <div
                    className={`w-3.5 h-3.5 rounded border flex items-center justify-center ${
                      st.completed
                        ? 'bg-cyan-500 border-cyan-400 text-slate-950'
                        : 'border-slate-600 bg-slate-900'
                    }`}
                  >
                    {st.completed && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                  </div>
                  <span className={st.completed ? 'line-through text-slate-500' : 'text-slate-300'}>
                    {st.title}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Hover / Action Controls */}
        <div className="flex items-center space-x-1 shrink-0 opacity-80 group-hover:opacity-100 transition-opacity">
          <button
            onClick={() => onEdit(task)}
            title="Edit task"
            className="p-1 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition-colors"
          >
            <Edit3 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onDelete(task.id)}
            title="Delete task"
            className="p-1 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
