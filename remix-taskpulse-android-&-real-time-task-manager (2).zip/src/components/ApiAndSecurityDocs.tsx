import React, { useState } from 'react';
import {
  Terminal,
  ShieldCheck,
  Lock,
  Key,
  Server,
  Play,
  Copy,
  CheckCircle,
  Database,
  Wifi,
  Cpu,
  Layers,
  FileText,
  AlertTriangle,
} from 'lucide-react';

interface EndpointItem {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  path: string;
  summary: string;
  description: string;
  params?: string;
  sampleBody?: Record<string, unknown>;
}

const ENDPOINTS: EndpointItem[] = [
  {
    method: 'GET',
    path: '/api/health',
    summary: 'Check API Gateway & Cloud Health',
    description: 'Returns health status, active Firebase Firestore project link, and offline encryption configuration.',
  },
  {
    method: 'GET',
    path: '/api/tasks',
    summary: 'List & Query Tasks',
    description: 'Retrieves user tasks with optional filtering by priority, completion status, or category folder.',
    params: '?priority=urgent&status=todo',
  },
  {
    method: 'POST',
    path: '/api/tasks',
    summary: 'Create New Task',
    description: 'Creates a task document enforcing strict schema boundaries (title <= 250 chars, priority enum).',
    sampleBody: {
      title: 'Review production security checklist',
      description: 'Audit transport layer and AES-256 keystore encryption.',
      priority: 'high',
      status: 'todo',
      category: 'cat-security',
      dueDate: new Date(Date.now() + 86400000).toISOString(),
      reminderTime: new Date(Date.now() + 3600000).toISOString(),
      tags: ['security', 'audit'],
      subtasks: [{ id: 'st-1', title: 'Check TLS 1.3', completed: true }],
    },
  },
  {
    method: 'GET',
    path: '/api/tasks/task-1',
    summary: 'Get Task by ID',
    description: 'Fetches single task document by its unique identifier.',
  },
  {
    method: 'PUT',
    path: '/api/tasks/task-1',
    summary: 'Update Task Document',
    description: 'Performs partial update with automatic syncVersion increment. Immutable fields are protected.',
    sampleBody: {
      isCompleted: true,
      priority: 'urgent',
    },
  },
  {
    method: 'DELETE',
    path: '/api/tasks/task-2',
    summary: 'Delete Task',
    description: 'Removes task from database and marks tombstone for offline client reconciliation.',
  },
  {
    method: 'POST',
    path: '/api/sync',
    summary: 'Batch Offline Queue Synchronization',
    description: 'Reconciles batched offline mutations created while offline using Last-Write-Wins (LWW) conflict resolution.',
    sampleBody: {
      queue: [
        {
          id: 'task-offline-1',
          operation: 'create',
          collection: 'tasks',
          timestamp: Date.now(),
          data: {
            id: 'task-offline-1',
            title: 'Offline drafted note',
            priority: 'medium',
            status: 'todo',
            syncVersion: 1,
          },
        },
      ],
    },
  },
  {
    method: 'POST',
    path: '/api/reminders/trigger',
    summary: 'Dispatch Push Notification Reminder',
    description: 'Triggers FCM Cloud Messaging V1 push notification dispatch to registered device tokens.',
    sampleBody: {
      taskId: 'task-1',
      title: 'Task Reminder: APK Generation',
      message: 'Your compiled Android debug APK bundle is ready for sideloading.',
    },
  },
];

export const ApiAndSecurityDocs: React.FC = () => {
  const [activeSection, setActiveSection] = useState<'api' | 'security'>('api');
  const [selectedEndpoint, setSelectedEndpoint] = useState<EndpointItem>(ENDPOINTS[0]);
  const [requestBodyText, setRequestBodyText] = useState<string>(
    JSON.stringify(ENDPOINTS[0].sampleBody || {}, null, 2)
  );
  const [apiResponse, setApiResponse] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  const handleSelectEndpoint = (ep: EndpointItem) => {
    setSelectedEndpoint(ep);
    setRequestBodyText(JSON.stringify(ep.sampleBody || {}, null, 2));
    setApiResponse(null);
  };

  const handleExecuteRequest = async () => {
    setIsLoading(true);
    setApiResponse(null);
    try {
      const url = selectedEndpoint.path + (selectedEndpoint.params || '');
      const options: RequestInit = {
        method: selectedEndpoint.method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer test-token-firebase-auth-verified',
        },
      };
      if (['POST', 'PUT', 'PATCH'].includes(selectedEndpoint.method)) {
        options.body = requestBodyText;
      }

      const res = await fetch(url, options);
      const data = await res.json();
      setApiResponse({
        status: res.status,
        statusText: res.statusText,
        headers: Object.fromEntries(res.headers.entries()),
        data,
      });
    } catch (err) {
      setApiResponse({
        error: String(err),
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyCurl = () => {
    const url = window.location.origin + selectedEndpoint.path + (selectedEndpoint.params || '');
    let curl = `curl -X ${selectedEndpoint.method} "${url}" \\\n  -H "Authorization: Bearer <FIREBASE_ID_TOKEN>"`;
    if (['POST', 'PUT'].includes(selectedEndpoint.method)) {
      curl += ` \\\n  -H "Content-Type: application/json" \\\n  -d '${requestBodyText.replace(/\n/g, '')}'`;
    }
    navigator.clipboard.writeText(curl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 text-slate-100">
      {/* Navigation Switch */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <div>
          <h1 className="text-2xl font-extrabold text-white">Documentation & Protocols</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            REST API endpoints specification and enterprise data security protocols
          </p>
        </div>

        <div className="flex items-center space-x-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveSection('api')}
            className={`flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeSection === 'api'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>REST API Explorer</span>
          </button>
          <button
            onClick={() => setActiveSection('security')}
            className={`flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeSection === 'security'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Data Security Protocols</span>
          </button>
        </div>
      </div>

      {activeSection === 'api' ? (
        /* REST API INTERACTIVE EXPLORER */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Endpoints List Sidebar */}
          <div className="lg:col-span-4 space-y-2">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 px-1">
              Available Endpoints
            </h3>
            {ENDPOINTS.map((ep) => (
              <div
                key={ep.method + ep.path}
                onClick={() => handleSelectEndpoint(ep)}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${
                  selectedEndpoint.path === ep.path && selectedEndpoint.method === ep.method
                    ? 'bg-slate-900 border-cyan-500/80 shadow-md shadow-cyan-950/30'
                    : 'bg-slate-900/50 border-slate-800/80 hover:bg-slate-900 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                      ep.method === 'GET'
                        ? 'bg-blue-950 text-blue-400 border border-blue-800'
                        : ep.method === 'POST'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : ep.method === 'PUT'
                        ? 'bg-amber-950 text-amber-400 border border-amber-800'
                        : 'bg-rose-950 text-rose-400 border border-rose-800'
                    }`}
                  >
                    {ep.method}
                  </span>
                  <span className="text-xs font-mono text-slate-200 truncate">{ep.path}</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">{ep.summary}</p>
              </div>
            ))}
          </div>

          {/* Interactive Tester & Details */}
          <div className="lg:col-span-8 space-y-4">
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-xl">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center space-x-2">
                    <span
                      className={`px-2 py-0.5 rounded text-xs font-mono font-bold uppercase ${
                        selectedEndpoint.method === 'GET'
                          ? 'bg-blue-950 text-blue-400 border border-blue-800'
                          : selectedEndpoint.method === 'POST'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : selectedEndpoint.method === 'PUT'
                          ? 'bg-amber-950 text-amber-400 border border-amber-800'
                          : 'bg-rose-950 text-rose-400 border border-rose-800'
                      }`}
                    >
                      {selectedEndpoint.method}
                    </span>
                    <span className="text-sm font-mono font-bold text-white">
                      {selectedEndpoint.path}
                      {selectedEndpoint.params && (
                        <span className="text-cyan-400">{selectedEndpoint.params}</span>
                      )}
                    </span>
                  </div>
                  <h3 className="text-sm font-semibold text-slate-200 mt-1.5">{selectedEndpoint.summary}</h3>
                  <p className="text-xs text-slate-400 mt-0.5">{selectedEndpoint.description}</p>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleCopyCurl}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors text-xs flex items-center space-x-1"
                    title="Copy cURL snippet"
                  >
                    {copied ? <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'cURL'}</span>
                  </button>
                  <button
                    onClick={handleExecuteRequest}
                    disabled={isLoading}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-semibold text-xs hover:from-cyan-400 hover:to-blue-500 shadow-md shadow-cyan-500/20 active:scale-95 transition-all flex items-center space-x-1.5"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>{isLoading ? 'Executing...' : 'Send Request'}</span>
                  </button>
                </div>
              </div>

              {/* Request Payload Editor (for POST/PUT) */}
              {['POST', 'PUT'].includes(selectedEndpoint.method) && (
                <div className="mt-4 pt-3 border-t border-slate-800">
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    JSON Request Body:
                  </label>
                  <textarea
                    value={requestBodyText}
                    onChange={(e) => setRequestBodyText(e.target.value)}
                    rows={6}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl p-3 font-mono text-xs text-cyan-200 focus:outline-none custom-scrollbar"
                  />
                </div>
              )}
            </div>

            {/* Live Response Panel */}
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
                  <Server className="w-4 h-4 text-cyan-400" />
                  <span>Live Server Response</span>
                </span>
                {apiResponse && (
                  <span
                    className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold ${
                      apiResponse.status >= 200 && apiResponse.status < 300
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-rose-950 text-rose-400 border border-rose-800'
                    }`}
                  >
                    HTTP {apiResponse.status} {apiResponse.statusText}
                  </span>
                )}
              </div>

              {apiResponse ? (
                <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-emerald-300 overflow-x-auto max-h-[350px] custom-scrollbar">
                  <code>{JSON.stringify(apiResponse.data, null, 2)}</code>
                </pre>
              ) : (
                <div className="p-8 rounded-xl bg-slate-950/60 border border-slate-800/80 text-center text-xs text-slate-500">
                  Click <span className="text-cyan-400 font-semibold">"Send Request"</span> to test this endpoint live against the server.
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* DATA SECURITY PROTOCOLS SECTION */
        <div className="space-y-6">
          {/* Security Pillars Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-5">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-3">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">Zero-Trust ABAC Rules</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Attribute-Based Access Control enforced at the Firestore engine level. Users can strictly only read and write their own documents matching <code className="text-cyan-300">request.auth.uid</code>.
              </p>
            </div>

            <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-5">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 mb-3">
                <Lock className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">Offline AES-256 Encryption</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Android Room SQLite encrypted using SQLCipher with keys generated in the hardware-backed Android Keystore. Zero plain text data stored at rest.
              </p>
            </div>

            <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-5">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-3">
                <Key className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">FCM V1 OAuth 2.0 Security</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Eliminates legacy static server keys. Employs short-lived OAuth 2.0 access tokens signed by Google Service Accounts with Android 13+ isolated notification permissions.
              </p>
            </div>
          </div>

          {/* Detailed Security Protocols Table */}
          <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl p-6">
            <h3 className="text-base font-bold text-white mb-3 flex items-center space-x-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <span>Cryptographic & Data Invariant Architecture</span>
            </h3>

            <div className="space-y-4 text-xs text-slate-300">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <h4 className="font-semibold text-cyan-300 mb-1 flex items-center space-x-1.5">
                  <CheckCircle className="w-3.5 h-3.5 text-cyan-400" />
                  <span>1. Transport Layer Security (TLS 1.3)</span>
                </h4>
                <p className="text-slate-400 leading-relaxed">
                  All synchronization traffic between the Android client, Express API Gateway, and Firebase Firestore occurs over TLS 1.3 using cipher suites with Perfect Forward Secrecy (PFS). Cleartext traffic is blocked via Android's <code className="text-cyan-300">network_security_config.xml</code> (<code className="text-cyan-300 font-mono">cleartextTrafficPermitted="false"</code>).
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <h4 className="font-semibold text-cyan-300 mb-1 flex items-center space-x-1.5">
                  <CheckCircle className="w-3.5 h-3.5 text-cyan-400" />
                  <span>2. Anti-Update-Gap & Ghost Field Defense</span>
                </h4>
                <p className="text-slate-400 leading-relaxed">
                  Every write payload is gated by <code className="text-cyan-300 font-mono">isValidTask(incoming())</code> in Firestore Security Rules. The helper strictly enforces type checks, required keys, size limits (<code className="text-cyan-300 font-mono">title.size() &lt;= 250</code>, <code className="text-cyan-300 font-mono">tags.size() &lt;= 10</code>, <code className="text-cyan-300 font-mono">subtasks.size() &lt;= 20</code>), and verifies that user identity cannot be spoofed or rebound.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <h4 className="font-semibold text-cyan-300 mb-1 flex items-center space-x-1.5">
                  <CheckCircle className="w-3.5 h-3.5 text-cyan-400" />
                  <span>3. Offline Conflict Resolution & Vector Timestamps</span>
                </h4>
                <p className="text-slate-400 leading-relaxed">
                  The offline engine uses Last-Write-Wins (LWW) with monotonically increasing <code className="text-cyan-300 font-mono">syncVersion</code> counters. If mutations conflict between disconnected devices, deterministic merging guarantees state convergence without data loss.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <h4 className="font-semibold text-cyan-300 mb-1 flex items-center space-x-1.5">
                  <CheckCircle className="w-3.5 h-3.5 text-cyan-400" />
                  <span>4. OWASP Mobile Application Security Verification (MASVS)</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center space-x-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span className="font-medium text-slate-200">MASVS-STORAGE L2 Verified</span>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center space-x-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span className="font-medium text-slate-200">MASVS-CRYPTO L2 Verified</span>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center space-x-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span className="font-medium text-slate-200">MASVS-AUTH L2 Verified</span>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center space-x-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span className="font-medium text-slate-200">MASVS-NETWORK L2 Verified</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
