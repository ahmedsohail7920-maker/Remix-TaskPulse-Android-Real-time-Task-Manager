import React, { useState } from 'react';
import {
  Clock,
  Play,
  CheckCircle,
  ToggleLeft,
  ToggleRight,
  Sparkles,
  Layers,
  Calendar,
  AlertCircle,
} from 'lucide-react';
import { zoyaToolRegistry, ScheduledWorkflow } from '../lib/zoyaTools';

interface WorkflowsPanelProps {
  workflows: ScheduledWorkflow[];
}

export const WorkflowsPanel: React.FC<WorkflowsPanelProps> = ({ workflows }) => {
  const [runningId, setRunningId] = useState<string | null>(null);

  const handleToggle = (id: string) => {
    zoyaToolRegistry.toggleWorkflow(id);
  };

  const handleRun = async (id: string) => {
    setRunningId(id);
    try {
      await zoyaToolRegistry.runWorkflow(id);
    } finally {
      setRunningId(null);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 text-slate-100">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <div>
          <h1 className="text-2xl font-extrabold text-white flex items-center space-x-2">
            <Clock className="w-6 h-6 text-cyan-400" />
            <span>Zoya Scheduled Automated Workflows</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Autonomous routines executed with cryptographic result verification and background scheduling
          </p>
        </div>
      </div>

      {/* Workflow Cards */}
      <div className="space-y-4">
        {workflows.map((wf) => (
          <div
            key={wf.id}
            className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-xl hover:border-slate-700 transition-colors"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center space-x-2.5">
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      wf.enabled
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {wf.enabled ? 'Active Schedule' : 'Paused'}
                  </span>
                  <span className="text-xs font-mono text-cyan-400 flex items-center space-x-1">
                    <Calendar className="w-3 h-3" />
                    <span>{wf.cronOrInterval}</span>
                  </span>
                </div>
                <h3 className="text-base font-bold text-white mt-1.5">{wf.title}</h3>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">{wf.description}</p>

                {/* Sub-actions Pills */}
                <div className="flex flex-wrap items-center gap-1.5 mt-3">
                  <span className="text-[10px] text-slate-500 font-semibold uppercase">Routine Steps:</span>
                  {wf.actions.map((act) => (
                    <span
                      key={act}
                      className="px-2 py-0.5 rounded-md text-[10px] font-mono bg-slate-950 border border-slate-800 text-slate-300"
                    >
                      {act}
                    </span>
                  ))}
                </div>

                {/* Last Run & Result */}
                {wf.lastRun && (
                  <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex flex-wrap items-center gap-3 text-[11px] text-slate-400">
                    <span>
                      Last Run: <strong className="text-slate-200">{wf.lastRun}</strong>
                    </span>
                    {wf.lastResult && (
                      <span className="flex items-center space-x-1 text-emerald-400">
                        <CheckCircle className="w-3 h-3" />
                        <span>{wf.lastResult}</span>
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Action Controls */}
              <div className="flex items-center space-x-3 shrink-0">
                <button
                  onClick={() => handleToggle(wf.id)}
                  className="p-1 rounded-xl text-slate-400 hover:text-white"
                  title={wf.enabled ? 'Pause schedule' : 'Enable schedule'}
                >
                  {wf.enabled ? (
                    <ToggleRight className="w-8 h-8 text-emerald-400" />
                  ) : (
                    <ToggleLeft className="w-8 h-8 text-slate-600" />
                  )}
                </button>

                <button
                  onClick={() => handleRun(wf.id)}
                  disabled={runningId === wf.id}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-cyan-500 text-slate-950 hover:bg-cyan-400 disabled:opacity-50 transition-all flex items-center space-x-1.5 shadow-md shadow-cyan-500/20 active:scale-95"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>{runningId === wf.id ? 'Running...' : 'Run Now'}</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
