import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Plus,
  CheckCircle2,
  Calendar,
  AlertTriangle,
  Folder,
} from 'lucide-react';
import { Task, Category, Priority } from '../types';
import { TaskCard } from './TaskCard';

interface TaskListProps {
  tasks: Task[];
  categories: Category[];
  onToggleComplete: (id: string) => void;
  onEdit: (task: Task) => void;
  onDelete: (id: string) => void;
  onToggleSubtask: (taskId: string, subtaskId: string) => void;
  onOpenCreateModal: () => void;
}

export const TaskList: React.FC<TaskListProps> = ({
  tasks,
  categories,
  onToggleComplete,
  onEdit,
  onDelete,
  onToggleSubtask,
  onOpenCreateModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTab, setFilterTab] = useState<'all' | 'today' | 'urgent' | 'pending' | 'completed'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const filteredTasks = useMemo(() => {
    return tasks.filter((task) => {
      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = task.title.toLowerCase().includes(query);
        const matchesDesc = task.description?.toLowerCase().includes(query);
        const matchesTags = task.tags?.some((t) => t.toLowerCase().includes(query));
        if (!matchesTitle && !matchesDesc && !matchesTags) return false;
      }

      // Category filter
      if (selectedCategory !== 'all' && task.category !== selectedCategory) {
        return false;
      }

      // Tab filter
      const now = new Date();
      if (filterTab === 'pending') {
        return !task.isCompleted;
      }
      if (filterTab === 'completed') {
        return task.isCompleted;
      }
      if (filterTab === 'urgent') {
        return task.priority === 'urgent' || task.priority === 'high';
      }
      if (filterTab === 'today') {
        if (!task.dueDate) return false;
        const d = new Date(task.dueDate);
        return d.toDateString() === now.toDateString();
      }

      return true;
    });
  }, [tasks, searchQuery, filterTab, selectedCategory]);

  const completedCount = tasks.filter((t) => t.isCompleted).length;
  const totalCount = tasks.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return (
    <div className="flex-1 flex flex-col p-4 sm:p-5 text-slate-100">
      {/* Header & Productivity Progress */}
      <div className="mb-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white flex items-center space-x-2">
              <span>My Tasks</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 font-mono">
                {filteredTasks.length}
              </span>
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">Real-time sync enabled with offline fallback</p>
          </div>

          <button
            onClick={onOpenCreateModal}
            className="flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 hover:from-cyan-400 hover:to-blue-500 shadow-lg shadow-cyan-500/20 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">New Task</span>
          </button>
        </div>

        {/* Progress Bar */}
        {totalCount > 0 && (
          <div className="mt-3 bg-slate-900/80 rounded-xl p-2.5 border border-slate-800">
            <div className="flex items-center justify-between text-xs mb-1.5 font-medium">
              <span className="text-slate-400 flex items-center space-x-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Productivity Progress</span>
              </span>
              <span className="font-mono text-cyan-400">{completedCount}/{totalCount} ({progressPercent}%)</span>
            </div>
            <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Search Bar */}
      <div className="relative mb-3">
        <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search tasks, descriptions, or #tags..."
          className="w-full bg-slate-900/90 border border-slate-800 focus:border-cyan-500 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none transition-colors"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
          >
            Clear
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center space-x-1 overflow-x-auto pb-1 mb-3 custom-scrollbar text-xs">
        <button
          onClick={() => setFilterTab('all')}
          className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
            filterTab === 'all'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          All Tasks
        </button>
        <button
          onClick={() => setFilterTab('today')}
          className={`flex items-center space-x-1 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
            filterTab === 'today'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Calendar className="w-3 h-3" />
          <span>Today</span>
        </button>
        <button
          onClick={() => setFilterTab('urgent')}
          className={`flex items-center space-x-1 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
            filterTab === 'urgent'
              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <AlertTriangle className="w-3 h-3 text-rose-400" />
          <span>Priority</span>
        </button>
        <button
          onClick={() => setFilterTab('pending')}
          className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
            filterTab === 'pending'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          Pending
        </button>
        <button
          onClick={() => setFilterTab('completed')}
          className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
            filterTab === 'completed'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          Completed
        </button>
      </div>

      {/* Category Pills */}
      <div className="flex items-center space-x-1.5 overflow-x-auto pb-2 mb-3 custom-scrollbar text-[11px]">
        <span className="text-slate-500 flex items-center space-x-1 mr-1">
          <Folder className="w-3 h-3" />
          <span className="hidden sm:inline">Folder:</span>
        </span>
        <button
          onClick={() => setSelectedCategory('all')}
          className={`px-2 py-0.5 rounded-md whitespace-nowrap ${
            selectedCategory === 'all'
              ? 'bg-slate-800 text-white font-medium border border-slate-700'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          All Folders
        </button>
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-2 py-0.5 rounded-md whitespace-nowrap flex items-center space-x-1 transition-colors ${
              selectedCategory === cat.id
                ? 'bg-slate-800 text-white font-semibold border'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            style={{
              borderColor: selectedCategory === cat.id ? cat.color : 'transparent',
            }}
          >
            <span
              className="w-1.5 h-1.5 rounded-full"
              style={{ backgroundColor: cat.color }}
            />
            <span>{cat.name}</span>
          </button>
        ))}
      </div>

      {/* Task List Content */}
      <div className="flex-1 space-y-2.5 overflow-y-auto">
        {filteredTasks.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center text-center p-6 rounded-2xl bg-slate-900/40 border border-slate-800/80">
            <CheckCircle2 className="w-10 h-10 text-slate-600 mb-2" />
            <h3 className="text-sm font-semibold text-slate-300">No tasks found</h3>
            <p className="text-xs text-slate-500 max-w-xs mt-1">
              {searchQuery
                ? 'No tasks matched your search query. Try clearing the filter.'
                : 'You have no tasks in this view. Tap "+ New Task" to create one!'}
            </p>
            <button
              onClick={onOpenCreateModal}
              className="mt-4 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-cyan-500 text-slate-950 hover:bg-cyan-400 transition-colors"
            >
              Add First Task
            </button>
          </div>
        ) : (
          filteredTasks.map((task) => (
            <TaskCard
              key={task.id}
              task={task}
              onToggleComplete={onToggleComplete}
              onEdit={onEdit}
              onDelete={onDelete}
              onToggleSubtask={onToggleSubtask}
            />
          ))
        )}
      </div>

      {/* Mobile Floating Action Button */}
      <button
        onClick={onOpenCreateModal}
        className="fixed bottom-10 right-6 sm:bottom-12 sm:right-10 w-12 h-12 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 flex items-center justify-center shadow-xl shadow-cyan-500/30 hover:scale-105 active:scale-95 transition-all z-30"
        title="Add new task"
      >
        <Plus className="w-6 h-6 stroke-[2.5]" />
      </button>
    </div>
  );
};
