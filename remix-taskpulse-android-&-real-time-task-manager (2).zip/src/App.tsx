/**
 * Zoya AI: Main Application Entry Point
 * Personal Intelligent Voice Assistant & Autonomous Task Automation System
 * Replaces legacy task manager with Zoya AI as the central engine,
 * featuring real-time Firebase sync, Gmail OAuth, WhatsApp workflows, and APK export.
 */
import React, { useState, useEffect } from 'react';
import { Navbar, ActiveTab } from './components/Navbar';
import { ZoyaCommandCenter } from './components/ZoyaCommandCenter';
import { AndroidEmulatorFrame } from './components/AndroidEmulatorFrame';
import { TaskList } from './components/TaskList';
import { TaskModal } from './components/TaskModal';
import { ApkBuildSuite } from './components/ApkBuildSuite';
import { ApiAndSecurityDocs } from './components/ApiAndSecurityDocs';
import { NotificationDrawer } from './components/NotificationDrawer';
import { ZoyaFloatingAssistant } from './components/ZoyaFloatingAssistant';
import { ZoyaFloatingCharacter } from './components/ZoyaFloatingCharacter';
import { ZoyaApprovalModal } from './components/ZoyaApprovalModal';
import { WorkflowsPanel } from './components/WorkflowsPanel';
import { offlineStore } from './lib/offlineStore';
import { notificationManager, ActiveHeadsUpAlert } from './lib/notificationManager';
import { zoyaToolRegistry, PendingToolApproval, ScheduledWorkflow } from './lib/zoyaTools';
import { testFirebaseConnection } from './lib/firebase';
import { Task, Category, SyncState } from './types';
import { Sparkles, Plus, ListTodo } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('zoya');
  const [tasks, setTasks] = useState<Task[]>(offlineStore.getTasks());
  const [categories, setCategories] = useState<Category[]>(offlineStore.getCategories());
  const [syncState, setSyncState] = useState<SyncState>(offlineStore.getSyncState());
  const [pendingQueue, setPendingQueue] = useState(offlineStore.getSyncQueue());
  const [isOfflineSim, setIsOfflineSim] = useState(offlineStore.isOfflineMode());
  const [activeAlerts, setActiveAlerts] = useState<ActiveHeadsUpAlert[]>(
    notificationManager.getActiveAlerts()
  );
  const [pendingApprovals, setPendingApprovals] = useState<PendingToolApproval[]>(
    zoyaToolRegistry.getPendingApprovals()
  );
  const [workflows, setWorkflows] = useState<ScheduledWorkflow[]>(
    zoyaToolRegistry.getWorkflows()
  );

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [showAssistantCockpit, setShowAssistantCockpit] = useState(false);

  // Subscribe to store updates
  useEffect(() => {
    const unsubStore = offlineStore.subscribe(() => {
      setTasks(offlineStore.getTasks());
      setCategories(offlineStore.getCategories());
      setSyncState(offlineStore.getSyncState());
      setPendingQueue(offlineStore.getSyncQueue());
      setIsOfflineSim(offlineStore.isOfflineMode());
    });

    const unsubNotif = notificationManager.subscribe(() => {
      setActiveAlerts(notificationManager.getActiveAlerts());
    });

    const unsubTools = zoyaToolRegistry.subscribe(() => {
      setPendingApprovals(zoyaToolRegistry.getPendingApprovals());
      setWorkflows(zoyaToolRegistry.getWorkflows());
    });

    // Test Firestore connectivity on boot
    testFirebaseConnection();

    return () => {
      unsubStore();
      unsubNotif();
      unsubTools();
    };
  }, []);

  // Task Actions
  const handleCreateTask = () => {
    setEditingTask(null);
    setIsModalOpen(true);
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setIsModalOpen(true);
  };

  const handleSaveTask = (
    taskData: Omit<Task, 'id' | 'userId' | 'syncVersion' | 'createdAt' | 'updatedAt'>
  ) => {
    if (editingTask) {
      offlineStore.updateTask(editingTask.id, taskData);
    } else {
      offlineStore.addTask(taskData);
    }
  };

  const handleToggleComplete = (id: string) => {
    offlineStore.toggleTaskCompletion(id);
  };

  const handleDeleteTask = (id: string) => {
    offlineStore.deleteTask(id);
  };

  const handleToggleSubtask = (taskId: string, subtaskId: string) => {
    const task = tasks.find((t) => t.id === taskId);
    if (!task || !task.subtasks) return;

    const updatedSubtasks = task.subtasks.map((st) =>
      st.id === subtaskId ? { ...st, completed: !st.completed } : st
    );

    const allDone = updatedSubtasks.length > 0 && updatedSubtasks.every((st) => st.completed);

    offlineStore.updateTask(taskId, {
      subtasks: updatedSubtasks,
      isCompleted: allDone ? true : task.isCompleted,
      status: allDone ? 'completed' : task.status,
    });
  };

  // Offline Simulator Toggle
  const handleToggleOffline = () => {
    const nextVal = !isOfflineSim;
    offlineStore.setSimulatedOffline(nextVal);
  };

  const handleManualSync = () => {
    offlineStore.drainQueue();
  };

  // Notification Heads-up handlers
  const handleDismissAlert = (id: string) => {
    notificationManager.dismissAlert(id);
  };

  const handleCompleteAlert = (alertId: string, taskId: string) => {
    notificationManager.completeTaskFromAlert(alertId, taskId);
  };

  const handleSnoozeAlert = (alertId: string, taskId: string) => {
    notificationManager.snoozeTaskFromAlert(alertId, taskId, 10);
  };

  const handleTriggerTestNotification = () => {
    const targetTask = tasks[0] || {
      id: 'test-reminder',
      title: 'Production APK Build Ready',
      priority: 'urgent',
    };
    notificationManager.triggerNotification(
      targetTask,
      'Test push reminder: Your task deadline is approaching! Tap Done to complete.'
    );
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        syncState={syncState}
        pendingCount={pendingQueue.length}
        isSimulatedOffline={isOfflineSim}
        onToggleOffline={handleToggleOffline}
        onManualSync={handleManualSync}
        unreadNotifications={activeAlerts.length}
      />

      {/* Main View Area */}
      <main className="flex-1 flex flex-col">
        {/* Zoya AI Command Center (Default View) */}
        {activeTab === 'zoya' && (
          <ZoyaCommandCenter
            tasks={tasks}
            onOpenCreateTask={handleCreateTask}
            onEditTask={handleEditTask}
            onToggleComplete={handleToggleComplete}
            onOpenWorkflows={() => setActiveTab('workflows')}
            onOpenEmulator={() => setActiveTab('emulator')}
          />
        )}

        {/* Full-width Tasks View */}
        {activeTab === 'tasks' && (
          <div className="max-w-4xl mx-auto w-full px-4 py-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold flex items-center space-x-2 text-white">
                  <ListTodo className="w-6 h-6 text-cyan-400" />
                  <span>Tasks & Autonomous Scheduling</span>
                </h1>
                <p className="text-xs text-slate-400">
                  Manage tasks directly or give voice commands to Zoya in Roman Urdu & English
                </p>
              </div>
              <button
                onClick={handleCreateTask}
                className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Naya Task</span>
              </button>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl">
              <TaskList
                tasks={tasks}
                categories={categories}
                onToggleComplete={handleToggleComplete}
                onEdit={handleEditTask}
                onDelete={handleDeleteTask}
                onToggleSubtask={handleToggleSubtask}
                onOpenCreateModal={handleCreateTask}
              />
            </div>
          </div>
        )}

        {/* Workflows Panel */}
        {activeTab === 'workflows' && <WorkflowsPanel workflows={workflows} />}

        {/* Mobile Pixel Emulator View */}
        {activeTab === 'emulator' && (
          <AndroidEmulatorFrame
            isOffline={isOfflineSim}
            activeAlerts={activeAlerts}
            onDismissAlert={handleDismissAlert}
            onCompleteAlert={handleCompleteAlert}
            onSnoozeAlert={handleSnoozeAlert}
            onOpenCreateModal={handleCreateTask}
          >
            <TaskList
              tasks={tasks}
              categories={categories}
              onToggleComplete={handleToggleComplete}
              onEdit={handleEditTask}
              onDelete={handleDeleteTask}
              onToggleSubtask={handleToggleSubtask}
              onOpenCreateModal={handleCreateTask}
            />
          </AndroidEmulatorFrame>
        )}

        {/* APK Build Suite */}
        {activeTab === 'apk' && <ApkBuildSuite />}

        {/* REST API & Security Specs */}
        {activeTab === 'api' && <ApiAndSecurityDocs />}

        {/* Reminders & Push Alarms */}
        {activeTab === 'notifications' && (
          <NotificationDrawer
            tasks={tasks}
            onTriggerTestNotification={handleTriggerTestNotification}
          />
        )}
      </main>

      {/* Task Creation & Edit Modal */}
      <TaskModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveTask}
        editingTask={editingTask}
        categories={categories}
      />

      {/* Zoya Mandatory Security Approval Modal */}
      <ZoyaApprovalModal approvals={pendingApprovals} />

      {/* Zoya Animated Floating Character with Expressive Emotions */}
      <ZoyaFloatingCharacter
        currentTasks={tasks}
        onOpenAssistantModal={() => setShowAssistantCockpit((prev) => !prev)}
      />

      {/* Zoya AI Draggable Full Chat Cockpit */}
      <ZoyaFloatingAssistant
        currentTasks={tasks}
        isOpen={showAssistantCockpit}
        onClose={() => setShowAssistantCockpit(false)}
      />
    </div>
  );
}
